import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'testsearch_widget.dart' show TestsearchWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:text_search/text_search.dart';

class TestsearchModel extends FlutterFlowModel<TestsearchWidget> {
  ///  Local state fields for this page.

  bool? searchUni;

  List<String> filterUni = [];
  void addToFilterUni(String item) => filterUni.add(item);
  void removeFromFilterUni(String item) => filterUni.remove(item);
  void removeAtIndexFromFilterUni(int index) => filterUni.removeAt(index);
  void insertAtIndexInFilterUni(int index, String item) =>
      filterUni.insert(index, item);
  void updateFilterUniAtIndex(int index, Function(String) updateFn) =>
      filterUni[index] = updateFn(filterUni[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for search widget.
  FocusNode? searchFocusNode;
  TextEditingController? searchTextController;
  String? Function(BuildContext, String?)? searchTextControllerValidator;
  List<UniversityRecord> simpleSearchResults = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    searchFocusNode?.dispose();
    searchTextController?.dispose();
  }
}
