import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/student/chat/chat_widget.dart';
import 'chat_m_screen_widget.dart' show ChatMScreenWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChatMScreenModel extends FlutterFlowModel<ChatMScreenWidget> {
  ///  Local state fields for this page.

  String? inputContent = '';

  dynamic chatHistory;

  bool aiResponding = false;

  ///  State fields for stateful widgets in this page.

  // Model for Chat component.
  late ChatModel chatModel;

  @override
  void initState(BuildContext context) {
    chatModel = createModel(context, () => ChatModel());
  }

  @override
  void dispose() {
    chatModel.dispose();
  }
}
