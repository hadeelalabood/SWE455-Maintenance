import '/backend/backend.dart';
import '/components/registration_notification/registration_notification_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'student_university_view_widget.dart' show StudentUniversityViewWidget;
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class StudentUniversityViewModel
    extends FlutterFlowModel<StudentUniversityViewWidget> {
  ///  Local state fields for this page.

  bool readMoreIsExpanded = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
