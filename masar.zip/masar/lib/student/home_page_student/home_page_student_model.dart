import '/backend/backend.dart';
import '/components/student_nav_bar_copy/student_nav_bar_copy_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/permissions_util.dart';
import '/index.dart';
import 'home_page_student_widget.dart' show HomePageStudentWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageStudentModel extends FlutterFlowModel<HomePageStudentWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for studentNavBarCopy component.
  late StudentNavBarCopyModel studentNavBarCopyModel;

  @override
  void initState(BuildContext context) {
    studentNavBarCopyModel =
        createModel(context, () => StudentNavBarCopyModel());
  }

  @override
  void dispose() {
    studentNavBarCopyModel.dispose();
  }
}
