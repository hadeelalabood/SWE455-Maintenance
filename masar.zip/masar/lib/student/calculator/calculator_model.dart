import '/backend/backend.dart';
import '/components/student_nav_bar_copy/student_nav_bar_copy_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/permissions_util.dart';
import 'calculator_widget.dart' show CalculatorWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CalculatorModel extends FlutterFlowModel<CalculatorWidget> {
  ///  Local state fields for this page.

  bool? total100 = true;

  int? drop1 = 0;

  int? drop2 = 0;

  int? drop3 = 0;

  int? finalResult;

  bool ableResult = false;

  int? drop4 = 0;

  bool greater1 = true;

  double? text1 = 0.0;

  double? text2 = 0.0;

  double? text3 = 0.0;

  double? text4 = 0.0;

  bool graeter2 = true;

  bool greater3 = true;

  bool greater4 = true;

  double? resultdouble = 0.0;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for text1 widget.
  FocusNode? text1FocusNode;
  TextEditingController? text1TextController;
  String? Function(BuildContext, String?)? text1TextControllerValidator;
  String? _text1TextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 5) {
      return 'يجب ان لا يتجاوز 5 خانات !';
    }
    if (!RegExp('^\\d+(\\.\\d+)?\$').hasMatch(val)) {
      return 'يجب ان تكون الدرجة تتكون من ارقام لا تحتوي على أحرف او رموز!';
    }
    return null;
  }

  // State field(s) for calc1 widget.
  String? calc1Value;
  FormFieldController<String>? calc1ValueController;
  // State field(s) for text2 widget.
  FocusNode? text2FocusNode;
  TextEditingController? text2TextController;
  String? Function(BuildContext, String?)? text2TextControllerValidator;
  String? _text2TextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 5) {
      return 'يجب ان لا يتجاوز 5 خانات!';
    }
    if (!RegExp('^\\d+(\\.\\d+)?\$').hasMatch(val)) {
      return 'يجب ان تكون الدرجة تتكون من ارقام لا تحتوي على أحرف او رموز';
    }
    return null;
  }

  // State field(s) for calc2 widget.
  String? calc2Value;
  FormFieldController<String>? calc2ValueController;
  // State field(s) for text3 widget.
  FocusNode? text3FocusNode;
  TextEditingController? text3TextController;
  String? Function(BuildContext, String?)? text3TextControllerValidator;
  String? _text3TextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 5) {
      return 'يجب ان لا يتجاوز 5 خانات';
    }
    if (!RegExp('^\\d+(\\.\\d+)?\$').hasMatch(val)) {
      return 'يجب ان تكون الدرجة تتكون من ارقام لا تحتوي على أحرف او رموز';
    }
    return null;
  }

  // State field(s) for calc3 widget.
  String? calc3Value;
  FormFieldController<String>? calc3ValueController;
  // State field(s) for text4 widget.
  FocusNode? text4FocusNode;
  TextEditingController? text4TextController;
  String? Function(BuildContext, String?)? text4TextControllerValidator;
  String? _text4TextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 5) {
      return 'يجب ان لا يتجاوز 5 خانات!';
    }
    if (!RegExp('^\\d+(\\.\\d+)?\$').hasMatch(val)) {
      return 'يجب ان تكون الدرجة تتكون من ارقام لا تحتوي على أحرف او رموز';
    }
    return null;
  }

  // State field(s) for calc4 widget.
  String? calc4Value;
  FormFieldController<String>? calc4ValueController;
  // Model for studentNavBarCopy component.
  late StudentNavBarCopyModel studentNavBarCopyModel;

  @override
  void initState(BuildContext context) {
    text1TextControllerValidator = _text1TextControllerValidator;
    text2TextControllerValidator = _text2TextControllerValidator;
    text3TextControllerValidator = _text3TextControllerValidator;
    text4TextControllerValidator = _text4TextControllerValidator;
    studentNavBarCopyModel =
        createModel(context, () => StudentNavBarCopyModel());
  }

  @override
  void dispose() {
    text1FocusNode?.dispose();
    text1TextController?.dispose();

    text2FocusNode?.dispose();
    text2TextController?.dispose();

    text3FocusNode?.dispose();
    text3TextController?.dispose();

    text4FocusNode?.dispose();
    text4TextController?.dispose();

    studentNavBarCopyModel.dispose();
  }
}
