import '/backend/backend.dart';
import '/components/empty_mentor/empty_mentor_widget.dart';
import '/components/student_nav_bar_copy/student_nav_bar_copy_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'mentors_list_widget.dart' show MentorsListWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MentorsListModel extends FlutterFlowModel<MentorsListWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for studentNavBarCopy component.
  late StudentNavBarCopyModel studentNavBarCopyModel;

  @override
  void initState(BuildContext context) {
    studentNavBarCopyModel =
        createModel(context, () => StudentNavBarCopyModel());
  }

  @override
  void dispose() {
    studentNavBarCopyModel.dispose();
  }
}
