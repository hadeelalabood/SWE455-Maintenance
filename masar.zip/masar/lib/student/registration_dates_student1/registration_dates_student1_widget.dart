import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/empty_registration_date/empty_registration_date_widget.dart';
import '/components/registration_details/registration_details_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'registration_dates_student1_model.dart';
export 'registration_dates_student1_model.dart';

class RegistrationDatesStudent1Widget extends StatefulWidget {
  const RegistrationDatesStudent1Widget({super.key});

  static String routeName = 'registrationDatesStudent1';
  static String routePath = '/registrationDatesStudent1';

  @override
  State<RegistrationDatesStudent1Widget> createState() =>
      _RegistrationDatesStudent1WidgetState();
}

class _RegistrationDatesStudent1WidgetState
    extends State<RegistrationDatesStudent1Widget> {
  late RegistrationDatesStudent1Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => RegistrationDatesStudent1Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).logoColor2,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'مواعيد التسجيل للجامعات',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: '29LTAzer_masarFont',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                  useGoogleFonts: false,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              FlutterFlowWebView(
                content: 'https://tranquil-swan-d95eaa.netlify.app/',
                width: 390.0,
                height: 370.0,
                verticalScroll: false,
                horizontalScroll: false,
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 15.0),
                child: FlutterFlowChoiceChips(
                  options: [
                    ChipData('مفتوحة'),
                    ChipData('قريبة'),
                    ChipData('مغلقة')
                  ],
                  onChanged: (val) async {
                    safeSetState(
                        () => _model.choiceChipsValue = val?.firstOrNull);
                    if (_model.choiceChipsValue == 'مفتوحة') {
                      _model.open = true;
                      _model.close = false;
                      _model.soon = false;
                      safeSetState(() {});
                    } else {
                      if (_model.choiceChipsValue == 'قريبة') {
                        _model.open = false;
                        _model.close = false;
                        _model.soon = true;
                        safeSetState(() {});
                      } else {
                        if (_model.choiceChipsValue == 'مغلقة') {
                          _model.open = false;
                          _model.close = true;
                          _model.soon = false;
                          safeSetState(() {});
                        }
                      }
                    }
                  },
                  selectedChipStyle: ChipStyle(
                    backgroundColor: FlutterFlowTheme.of(context).logoColor2,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: FlutterFlowTheme.of(context).info,
                          letterSpacing: 0.0,
                        ),
                    iconColor: FlutterFlowTheme.of(context).info,
                    iconSize: 12.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  unselectedChipStyle: ChipStyle(
                    backgroundColor:
                        FlutterFlowTheme.of(context).secondaryBackground,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: FlutterFlowTheme.of(context).secondaryText,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                        ),
                    iconColor: FlutterFlowTheme.of(context).secondaryText,
                    iconSize: 16.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  chipSpacing: 8.0,
                  rowSpacing: 8.0,
                  multiselect: false,
                  initialized: _model.choiceChipsValue != null,
                  alignment: WrapAlignment.start,
                  controller: _model.choiceChipsValueController ??=
                      FormFieldController<List<String>>(
                    ['مفتوحة'],
                  ),
                  wrapped: true,
                ),
              ),
              if (_model.open)
                Expanded(
                  child: StreamBuilder<List<RegistrationDatesRecord>>(
                    stream: queryRegistrationDatesRecord(
                      queryBuilder: (registrationDatesRecord) =>
                          registrationDatesRecord
                              .where(
                                'startTime',
                                isLessThanOrEqualTo: getCurrentTimestamp,
                              )
                              .orderBy('startTime'),
                    ),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).alternate,
                              ),
                            ),
                          ),
                        );
                      }
                      List<RegistrationDatesRecord>
                          openListViewRegistrationDatesRecordList =
                          snapshot.data!;

                      return Container(
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Builder(
                            builder: (context) {
                              final containerVar =
                                  openListViewRegistrationDatesRecordList
                                      .where((e) =>
                                          e.endTime! >= getCurrentTimestamp)
                                      .toList();
                              if (containerVar.isEmpty) {
                                return EmptyRegistrationDateWidget(
                                  message: 'لا توجد مواعيد تسجيل مفتوحة حاليًا',
                                );
                              }

                              return ListView.separated(
                                padding: EdgeInsets.zero,
                                shrinkWrap: true,
                                scrollDirection: Axis.vertical,
                                itemCount: containerVar.length,
                                separatorBuilder: (_, __) =>
                                    SizedBox(height: 5.0),
                                itemBuilder: (context, containerVarIndex) {
                                  final containerVarItem =
                                      containerVar[containerVarIndex];
                                  return InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      _model.empty3 =
                                          await queryNotificationsRecordCount(
                                        queryBuilder: (notificationsRecord) =>
                                            notificationsRecord
                                                .where(
                                                  'user',
                                                  isEqualTo:
                                                      currentUserReference,
                                                )
                                                .where(
                                                  'regDate',
                                                  isEqualTo: containerVarItem
                                                      .reference,
                                                ),
                                      );
                                      if (_model.empty3 == 0) {
                                        var notificationsRecordReference =
                                            NotificationsRecord.collection
                                                .doc();
                                        await notificationsRecordReference
                                            .set(createNotificationsRecordData(
                                          user: currentUserReference,
                                          regDate: containerVarItem.reference,
                                          notification: false,
                                        ));
                                        _model.create3 = NotificationsRecord
                                            .getDocumentFromData(
                                                createNotificationsRecordData(
                                                  user: currentUserReference,
                                                  regDate: containerVarItem
                                                      .reference,
                                                  notification: false,
                                                ),
                                                notificationsRecordReference);
                                        await showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          enableDrag: false,
                                          context: context,
                                          builder: (context) {
                                            return WebViewAware(
                                              child: GestureDetector(
                                                onTap: () {
                                                  FocusScope.of(context)
                                                      .unfocus();
                                                  FocusManager
                                                      .instance.primaryFocus
                                                      ?.unfocus();
                                                },
                                                child: Padding(
                                                  padding:
                                                      MediaQuery.viewInsetsOf(
                                                          context),
                                                  child:
                                                      RegistrationDetailsWidget(
                                                    registration:
                                                        containerVarItem,
                                                    notification:
                                                        _model.create3,
                                                    status: 'open',
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        ).then((value) => safeSetState(() {}));
                                      } else {
                                        _model.update3 =
                                            await queryNotificationsRecordOnce(
                                          queryBuilder: (notificationsRecord) =>
                                              notificationsRecord
                                                  .where(
                                                    'user',
                                                    isEqualTo:
                                                        currentUserReference,
                                                  )
                                                  .where(
                                                    'regDate',
                                                    isEqualTo: containerVarItem
                                                        .reference,
                                                  ),
                                          singleRecord: true,
                                        ).then((s) => s.firstOrNull);
                                        await showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          enableDrag: false,
                                          context: context,
                                          builder: (context) {
                                            return WebViewAware(
                                              child: GestureDetector(
                                                onTap: () {
                                                  FocusScope.of(context)
                                                      .unfocus();
                                                  FocusManager
                                                      .instance.primaryFocus
                                                      ?.unfocus();
                                                },
                                                child: Padding(
                                                  padding:
                                                      MediaQuery.viewInsetsOf(
                                                          context),
                                                  child:
                                                      RegistrationDetailsWidget(
                                                    registration:
                                                        containerVarItem,
                                                    notification:
                                                        _model.update3,
                                                    status: 'open',
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        ).then((value) => safeSetState(() {}));
                                      }

                                      safeSetState(() {});
                                    },
                                    child: Container(
                                      width: 100.0,
                                      decoration: BoxDecoration(
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryBackground,
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      child: Padding(
                                        padding: EdgeInsets.all(15.0),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                containerVarItem.universityName,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              '29LTAzer_masarFont',
                                                          fontSize: 20.0,
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              ),
                                            ),
                                            Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                containerVarItem.description,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              '29LTAzer_masarFont',
                                                          fontSize: 20.0,
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                          ),
                        ),
                      );
                    },
                  ),
                ),
              if (_model.soon)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: StreamBuilder<List<RegistrationDatesRecord>>(
                      stream: queryRegistrationDatesRecord(
                        queryBuilder: (registrationDatesRecord) =>
                            registrationDatesRecord
                                .where(
                                  'startTime',
                                  isGreaterThan: getCurrentTimestamp,
                                )
                                .orderBy('startTime'),
                      ),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).alternate,
                                ),
                              ),
                            ),
                          );
                        }
                        List<RegistrationDatesRecord>
                            soonListViewRegistrationDatesRecordList =
                            snapshot.data!;
                        if (soonListViewRegistrationDatesRecordList.isEmpty) {
                          return EmptyRegistrationDateWidget(
                            message: 'لا توجد مواعيد تسجيل قريبة حاليًا',
                          );
                        }

                        return ListView.separated(
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemCount:
                              soonListViewRegistrationDatesRecordList.length,
                          separatorBuilder: (_, __) => SizedBox(height: 5.0),
                          itemBuilder: (context, soonListViewIndex) {
                            final soonListViewRegistrationDatesRecord =
                                soonListViewRegistrationDatesRecordList[
                                    soonListViewIndex];
                            return InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                _model.empty2 =
                                    await queryNotificationsRecordCount(
                                  queryBuilder: (notificationsRecord) =>
                                      notificationsRecord
                                          .where(
                                            'user',
                                            isEqualTo: currentUserReference,
                                          )
                                          .where(
                                            'regDate',
                                            isEqualTo:
                                                soonListViewRegistrationDatesRecord
                                                    .reference,
                                          ),
                                );
                                if (_model.empty2 == 0) {
                                  var notificationsRecordReference =
                                      NotificationsRecord.collection.doc();
                                  await notificationsRecordReference
                                      .set(createNotificationsRecordData(
                                    user: currentUserReference,
                                    regDate: soonListViewRegistrationDatesRecord
                                        .reference,
                                    notification: false,
                                  ));
                                  _model.create2 =
                                      NotificationsRecord.getDocumentFromData(
                                          createNotificationsRecordData(
                                            user: currentUserReference,
                                            regDate:
                                                soonListViewRegistrationDatesRecord
                                                    .reference,
                                            notification: false,
                                          ),
                                          notificationsRecordReference);
                                  await showModalBottomSheet(
                                    isScrollControlled: true,
                                    backgroundColor: Colors.transparent,
                                    enableDrag: false,
                                    context: context,
                                    builder: (context) {
                                      return WebViewAware(
                                        child: GestureDetector(
                                          onTap: () {
                                            FocusScope.of(context).unfocus();
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();
                                          },
                                          child: Padding(
                                            padding: MediaQuery.viewInsetsOf(
                                                context),
                                            child: RegistrationDetailsWidget(
                                              registration:
                                                  soonListViewRegistrationDatesRecord,
                                              notification: _model.create2,
                                              status: 'soon',
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ).then((value) => safeSetState(() {}));
                                } else {
                                  _model.update2 =
                                      await queryNotificationsRecordOnce(
                                    queryBuilder: (notificationsRecord) =>
                                        notificationsRecord
                                            .where(
                                              'user',
                                              isEqualTo: currentUserReference,
                                            )
                                            .where(
                                              'regDate',
                                              isEqualTo:
                                                  soonListViewRegistrationDatesRecord
                                                      .reference,
                                            ),
                                    singleRecord: true,
                                  ).then((s) => s.firstOrNull);
                                  await showModalBottomSheet(
                                    isScrollControlled: true,
                                    backgroundColor: Colors.transparent,
                                    enableDrag: false,
                                    context: context,
                                    builder: (context) {
                                      return WebViewAware(
                                        child: GestureDetector(
                                          onTap: () {
                                            FocusScope.of(context).unfocus();
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();
                                          },
                                          child: Padding(
                                            padding: MediaQuery.viewInsetsOf(
                                                context),
                                            child: RegistrationDetailsWidget(
                                              registration:
                                                  soonListViewRegistrationDatesRecord,
                                              notification: _model.update2,
                                              status: 'soon',
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ).then((value) => safeSetState(() {}));
                                }

                                safeSetState(() {});
                              },
                              child: Container(
                                width: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(15.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Text(
                                          soonListViewRegistrationDatesRecord
                                              .universityName,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Text(
                                          soonListViewRegistrationDatesRecord
                                              .description,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              if (_model.close)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: StreamBuilder<List<RegistrationDatesRecord>>(
                      stream: queryRegistrationDatesRecord(
                        queryBuilder: (registrationDatesRecord) =>
                            registrationDatesRecord
                                .where(
                                  'endTime',
                                  isLessThan: getCurrentTimestamp,
                                )
                                .orderBy('endTime'),
                      ),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).alternate,
                                ),
                              ),
                            ),
                          );
                        }
                        List<RegistrationDatesRecord>
                            closeListViewRegistrationDatesRecordList =
                            snapshot.data!;
                        if (closeListViewRegistrationDatesRecordList.isEmpty) {
                          return EmptyRegistrationDateWidget(
                            message: 'لا توجد مواعيد تسجيل مغلقة حاليًا',
                          );
                        }

                        return ListView.separated(
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemCount:
                              closeListViewRegistrationDatesRecordList.length,
                          separatorBuilder: (_, __) => SizedBox(height: 5.0),
                          itemBuilder: (context, closeListViewIndex) {
                            final closeListViewRegistrationDatesRecord =
                                closeListViewRegistrationDatesRecordList[
                                    closeListViewIndex];
                            return InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                _model.empty1 =
                                    await queryNotificationsRecordCount(
                                  queryBuilder: (notificationsRecord) =>
                                      notificationsRecord
                                          .where(
                                            'user',
                                            isEqualTo: currentUserReference,
                                          )
                                          .where(
                                            'regDate',
                                            isEqualTo:
                                                closeListViewRegistrationDatesRecord
                                                    .reference,
                                          ),
                                );
                                if (_model.empty1 == 0) {
                                  var notificationsRecordReference =
                                      NotificationsRecord.collection.doc();
                                  await notificationsRecordReference
                                      .set(createNotificationsRecordData(
                                    user: currentUserReference,
                                    regDate:
                                        closeListViewRegistrationDatesRecord
                                            .reference,
                                    notification: false,
                                  ));
                                  _model.create1 =
                                      NotificationsRecord.getDocumentFromData(
                                          createNotificationsRecordData(
                                            user: currentUserReference,
                                            regDate:
                                                closeListViewRegistrationDatesRecord
                                                    .reference,
                                            notification: false,
                                          ),
                                          notificationsRecordReference);
                                  await showModalBottomSheet(
                                    isScrollControlled: true,
                                    backgroundColor: Colors.transparent,
                                    enableDrag: false,
                                    context: context,
                                    builder: (context) {
                                      return WebViewAware(
                                        child: GestureDetector(
                                          onTap: () {
                                            FocusScope.of(context).unfocus();
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();
                                          },
                                          child: Padding(
                                            padding: MediaQuery.viewInsetsOf(
                                                context),
                                            child: RegistrationDetailsWidget(
                                              registration:
                                                  closeListViewRegistrationDatesRecord,
                                              notification: _model.create1,
                                              status: 'close',
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ).then((value) => safeSetState(() {}));
                                } else {
                                  _model.update1 =
                                      await queryNotificationsRecordOnce(
                                    queryBuilder: (notificationsRecord) =>
                                        notificationsRecord
                                            .where(
                                              'user',
                                              isEqualTo: currentUserReference,
                                            )
                                            .where(
                                              'regDate',
                                              isEqualTo:
                                                  closeListViewRegistrationDatesRecord
                                                      .reference,
                                            ),
                                    singleRecord: true,
                                  ).then((s) => s.firstOrNull);
                                  await showModalBottomSheet(
                                    isScrollControlled: true,
                                    backgroundColor: Colors.transparent,
                                    enableDrag: false,
                                    context: context,
                                    builder: (context) {
                                      return WebViewAware(
                                        child: GestureDetector(
                                          onTap: () {
                                            FocusScope.of(context).unfocus();
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();
                                          },
                                          child: Padding(
                                            padding: MediaQuery.viewInsetsOf(
                                                context),
                                            child: RegistrationDetailsWidget(
                                              registration:
                                                  closeListViewRegistrationDatesRecord,
                                              notification: _model.update1,
                                              status: 'close',
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ).then((value) => safeSetState(() {}));
                                }

                                safeSetState(() {});
                              },
                              child: Container(
                                width: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(15.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Text(
                                          closeListViewRegistrationDatesRecord
                                              .universityName,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, 0.0),
                                        child: Text(
                                          closeListViewRegistrationDatesRecord
                                              .description,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
