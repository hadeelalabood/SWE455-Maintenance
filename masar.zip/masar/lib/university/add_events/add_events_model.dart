import '/components/addeventform/addeventform_widget.dart';
import '/components/datet_time/datet_time_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'add_events_widget.dart' show AddEventsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddEventsModel extends FlutterFlowModel<AddEventsWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for addeventform component.
  late AddeventformModel addeventformModel1;
  // Model for addeventform component.
  late AddeventformModel addeventformModel2;
  // Model for datetTime component.
  late DatetTimeModel datetTimeModel1;
  // Model for datetTime component.
  late DatetTimeModel datetTimeModel2;
  // Stores action output result for [Custom Action - eventTojson] action in Button widget.
  dynamic? createdEvent;
  // Stores action output result for [Custom Action - signwithgoogle] action in Button widget.
  String? accessToken;

  @override
  void initState(BuildContext context) {
    addeventformModel1 = createModel(context, () => AddeventformModel());
    addeventformModel2 = createModel(context, () => AddeventformModel());
    datetTimeModel1 = createModel(context, () => DatetTimeModel());
    datetTimeModel2 = createModel(context, () => DatetTimeModel());
  }

  @override
  void dispose() {
    addeventformModel1.dispose();
    addeventformModel2.dispose();
    datetTimeModel1.dispose();
    datetTimeModel2.dispose();
  }
}
