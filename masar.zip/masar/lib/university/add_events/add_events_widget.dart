import '/components/addeventform/addeventform_widget.dart';
import '/components/datet_time/datet_time_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'add_events_model.dart';
export 'add_events_model.dart';

class AddEventsWidget extends StatefulWidget {
  const AddEventsWidget({super.key});

  static String routeName = 'addEvents';
  static String routePath = '/addEvents';

  @override
  State<AddEventsWidget> createState() => _AddEventsWidgetState();
}

class _AddEventsWidgetState extends State<AddEventsWidget> {
  late AddEventsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddEventsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).logoColor2,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pushNamed(
                RegistrationDatesWidget.routeName,
                queryParameters: {
                  'accessToken': serializeParam(
                    _model.accessToken,
                    ParamType.String,
                  ),
                }.withoutNulls,
              );
            },
          ),
          title: Text(
            'اضافة موعد',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: '29LTAzer_masarFont',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                  useGoogleFonts: false,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).primaryBackground,
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                wrapWithModel(
                  model: _model.addeventformModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: AddeventformWidget(
                    titleText: 'الجامعة:',
                    hintText: 'اكتب اسم الجامعة',
                  ),
                ),
                wrapWithModel(
                  model: _model.addeventformModel2,
                  updateCallback: () => safeSetState(() {}),
                  child: AddeventformWidget(
                    titleText: 'الوصف:',
                    hintText: 'الرجاء وصف الموعد',
                  ),
                ),
                wrapWithModel(
                  model: _model.datetTimeModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: DatetTimeWidget(
                    titleText: 'تاريخ البداية :',
                  ),
                ),
                wrapWithModel(
                  model: _model.datetTimeModel2,
                  updateCallback: () => safeSetState(() {}),
                  child: DatetTimeWidget(
                    titleText: 'تاريخ النهاية :',
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 50.0, 0.0, 0.0),
                  child: FFButtonWidget(
                    onPressed: () async {
                      _model.createdEvent = await actions.eventTojson(
                        _model.addeventformModel1.textController.text,
                        _model.addeventformModel2.textController.text,
                        _model.datetTimeModel1.datePicked!,
                        _model.datetTimeModel2.datePicked!,
                      );
                      _model.accessToken = await actions.signwithgoogle();
                      await actions.addeventtocallender(
                        _model.accessToken!,
                        _model.createdEvent!,
                      );

                      safeSetState(() {});
                    },
                    text: 'اضف الموعد',
                    options: FFButtonOptions(
                      height: 40.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: FlutterFlowTheme.of(context).logoColor2,
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: '29LTAzer_masarFont',
                                color: Colors.white,
                                letterSpacing: 0.0,
                                useGoogleFonts: false,
                              ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 50.0, 0.0, 0.0),
                  child: FFButtonWidget(
                    onPressed: () async {
                      context.pushNamed(
                        RegistrationDatesWidget.routeName,
                        queryParameters: {
                          'accessToken': serializeParam(
                            _model.accessToken,
                            ParamType.String,
                          ),
                        }.withoutNulls,
                      );
                    },
                    text: 'التقويم',
                    options: FFButtonOptions(
                      height: 40.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: FlutterFlowTheme.of(context).logoColor2,
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: '29LTAzer_masarFont',
                                color: Colors.white,
                                letterSpacing: 0.0,
                                useGoogleFonts: false,
                              ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
