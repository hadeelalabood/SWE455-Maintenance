import '/backend/backend.dart';
import '/components/add_event/add_event_widget.dart';
import '/components/university_nav_bar_copy/university_nav_bar_copy_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'registration_dates_university_widget.dart'
    show RegistrationDatesUniversityWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class RegistrationDatesUniversityModel
    extends FlutterFlowModel<RegistrationDatesUniversityWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for universityNavBarCopy component.
  late UniversityNavBarCopyModel universityNavBarCopyModel;

  @override
  void initState(BuildContext context) {
    universityNavBarCopyModel =
        createModel(context, () => UniversityNavBarCopyModel());
  }

  @override
  void dispose() {
    universityNavBarCopyModel.dispose();
  }
}
