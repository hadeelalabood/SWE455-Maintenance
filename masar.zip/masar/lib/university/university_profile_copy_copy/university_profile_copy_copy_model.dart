import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/cancel_edit_uni/cancel_edit_uni_widget.dart';
import '/components/edit_student_succesfully_copy/edit_student_succesfully_copy_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'university_profile_copy_copy_widget.dart'
    show UniversityProfileCopyCopyWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class UniversityProfileCopyCopyModel
    extends FlutterFlowModel<UniversityProfileCopyCopyWidget> {
  ///  Local state fields for this page.

  bool? nameUsed;

  bool? edit = false;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for Uniname widget.
  FocusNode? uninameFocusNode;
  TextEditingController? uninameTextController;
  String? Function(BuildContext, String?)? uninameTextControllerValidator;
  String? _uninameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 50) {
      return 'ادخل اسم لا يتجاوز 50 خانة';
    }
    if (!RegExp('^[\\u0621-\\u064A\\s]+\$').hasMatch(val)) {
      return 'الرجاء ادخال الاسم بشكل صحيح  \nولايحتوي على ارقام او رموز\nويجب أن يكون باللغة العربية';
    }
    return null;
  }

  // State field(s) for DescEdit widget.
  FocusNode? descEditFocusNode;
  TextEditingController? descEditTextController;
  String? Function(BuildContext, String?)? descEditTextControllerValidator;
  String? _descEditTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 150) {
      return 'أدخل وصف لا يتجاوز 150 حرف.';
    }

    return null;
  }

  // State field(s) for WebsiteEdit widget.
  FocusNode? websiteEditFocusNode;
  TextEditingController? websiteEditTextController;
  String? Function(BuildContext, String?)? websiteEditTextControllerValidator;
  String? _websiteEditTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 300) {
      return 'الرابط يجب أن لا يزيد عن 300 خانة.';
    }
    if (!RegExp(kTextValidatorWebsiteRegex).hasMatch(val)) {
      return 'الرجاء إدخال موقع إلكتروني صحيح.';
    }
    return null;
  }

  // State field(s) for ContactEdit widget.
  FocusNode? contactEditFocusNode;
  TextEditingController? contactEditTextController;
  String? Function(BuildContext, String?)? contactEditTextControllerValidator;
  String? _contactEditTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 100) {
      return 'البريد الإلكتروني يجب أن لا يزيد عن 100 خانة.';
    }
    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return 'الرجاء إدخال بريد إلكتروني صحيح.';
    }
    return null;
  }

  // State field(s) for XEdit widget.
  FocusNode? xEditFocusNode;
  TextEditingController? xEditTextController;
  String? Function(BuildContext, String?)? xEditTextControllerValidator;
  String? _xEditTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 300) {
      return 'الرابط يجب أن لا يزيد عن 300 خانة.';
    }
    if (!RegExp(kTextValidatorWebsiteRegex).hasMatch(val)) {
      return 'الرجاء إدخال رابط X صحيح.';
    }
    return null;
  }

  // Stores action output result for [Validate Form] action in Button widget.
  bool? uniEdit;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  int? uniName;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  int? uniused;

  @override
  void initState(BuildContext context) {
    uninameTextControllerValidator = _uninameTextControllerValidator;
    descEditTextControllerValidator = _descEditTextControllerValidator;
    websiteEditTextControllerValidator = _websiteEditTextControllerValidator;
    contactEditTextControllerValidator = _contactEditTextControllerValidator;
    xEditTextControllerValidator = _xEditTextControllerValidator;
  }

  @override
  void dispose() {
    uninameFocusNode?.dispose();
    uninameTextController?.dispose();

    descEditFocusNode?.dispose();
    descEditTextController?.dispose();

    websiteEditFocusNode?.dispose();
    websiteEditTextController?.dispose();

    contactEditFocusNode?.dispose();
    contactEditTextController?.dispose();

    xEditFocusNode?.dispose();
    xEditTextController?.dispose();
  }
}
