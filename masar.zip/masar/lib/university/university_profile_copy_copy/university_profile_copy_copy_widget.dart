import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/cancel_edit_uni/cancel_edit_uni_widget.dart';
import '/components/edit_student_succesfully_copy/edit_student_succesfully_copy_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'university_profile_copy_copy_model.dart';
export 'university_profile_copy_copy_model.dart';

class UniversityProfileCopyCopyWidget extends StatefulWidget {
  const UniversityProfileCopyCopyWidget({
    super.key,
    required this.uni,
  });

  final UniversityRecord? uni;

  static String routeName = 'universityProfileCopyCopy';
  static String routePath = '/universityProfileCopyCopy';

  @override
  State<UniversityProfileCopyCopyWidget> createState() =>
      _UniversityProfileCopyCopyWidgetState();
}

class _UniversityProfileCopyCopyWidgetState
    extends State<UniversityProfileCopyCopyWidget>
    with TickerProviderStateMixin {
  late UniversityProfileCopyCopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => UniversityProfileCopyCopyModel());

    _model.uninameFocusNode ??= FocusNode();

    _model.descEditFocusNode ??= FocusNode();

    _model.websiteEditFocusNode ??= FocusNode();

    _model.contactEditFocusNode ??= FocusNode();

    _model.xEditFocusNode ??= FocusNode();

    animationsMap.addAll({
      'dividerOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 1.ms),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 20.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
      'buttonOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 400.ms),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 400.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 400.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 60.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<UniversityRecord>>(
      stream: queryUniversityRecord(
        queryBuilder: (universityRecord) => universityRecord.where(
          'University',
          isEqualTo: currentUserReference,
        ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).alternate,
                  ),
                ),
              ),
            ),
          );
        }
        List<UniversityRecord> universityProfileCopyCopyUniversityRecordList =
            snapshot.data!;
        // Return an empty Container when the item does not exist.
        if (snapshot.data!.isEmpty) {
          return Container();
        }
        final universityProfileCopyCopyUniversityRecord =
            universityProfileCopyCopyUniversityRecordList.isNotEmpty
                ? universityProfileCopyCopyUniversityRecordList.first
                : null;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).logoColor2,
              automaticallyImplyLeading: false,
              leading: FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 30.0,
                borderWidth: 1.0,
                buttonSize: 60.0,
                icon: Icon(
                  Icons.arrow_back_rounded,
                  color: Colors.white,
                  size: 30.0,
                ),
                onPressed: () async {
                  context.pushNamed(
                    UniversityProfileWidget.routeName,
                    queryParameters: {
                      'uni': serializeParam(
                        widget!.uni,
                        ParamType.Document,
                      ),
                    }.withoutNulls,
                    extra: <String, dynamic>{
                      'uni': widget!.uni,
                    },
                  );
                },
              ),
              title: Text(
                'تعديل الملف الشخصي',
                style: FlutterFlowTheme.of(context).headlineMedium.override(
                      fontFamily: '29LTAzer_masarFont',
                      color: Colors.white,
                      fontSize: 22.0,
                      letterSpacing: 0.0,
                      useGoogleFonts: false,
                    ),
              ),
              actions: [],
              centerTitle: true,
              elevation: 2.0,
            ),
            body: SafeArea(
              top: true,
              child: Form(
                key: _model.formKey,
                autovalidateMode: AutovalidateMode.disabled,
                child: Container(
                  decoration: BoxDecoration(),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.0, 0.0),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                2.0, 20.0, 2.0, 0.0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(60.0),
                                bottomRight: Radius.circular(60.0),
                                topLeft: Radius.circular(60.0),
                                topRight: Radius.circular(60.0),
                              ),
                              child: Image.network(
                                universityProfileCopyCopyUniversityRecord!
                                    .profilePicture,
                                width: 100.0,
                                height: 100.0,
                                fit: BoxFit.cover,
                                alignment: Alignment(0.0, 0.0),
                              ),
                            ),
                          ),
                        ),
                        FlutterFlowIconButton(
                          borderRadius: 8.0,
                          buttonSize: 30.0,
                          fillColor: FlutterFlowTheme.of(context).logoColor2,
                          icon: Icon(
                            Icons.image,
                            color: FlutterFlowTheme.of(context).info,
                            size: 15.0,
                          ),
                          onPressed: () async {
                            final selectedMedia = await selectMedia(
                              mediaSource: MediaSource.photoGallery,
                              multiImage: false,
                            );
                            if (selectedMedia != null &&
                                selectedMedia.every((m) => validateFileFormat(
                                    m.storagePath, context))) {
                              safeSetState(() => _model.isDataUploading = true);
                              var selectedUploadedFiles = <FFUploadedFile>[];

                              var downloadUrls = <String>[];
                              try {
                                selectedUploadedFiles = selectedMedia
                                    .map((m) => FFUploadedFile(
                                          name: m.storagePath.split('/').last,
                                          bytes: m.bytes,
                                          height: m.dimensions?.height,
                                          width: m.dimensions?.width,
                                          blurHash: m.blurHash,
                                        ))
                                    .toList();

                                downloadUrls = (await Future.wait(
                                  selectedMedia.map(
                                    (m) async => await uploadData(
                                        m.storagePath, m.bytes),
                                  ),
                                ))
                                    .where((u) => u != null)
                                    .map((u) => u!)
                                    .toList();
                              } finally {
                                _model.isDataUploading = false;
                              }
                              if (selectedUploadedFiles.length ==
                                      selectedMedia.length &&
                                  downloadUrls.length == selectedMedia.length) {
                                safeSetState(() {
                                  _model.uploadedLocalFile =
                                      selectedUploadedFiles.first;
                                  _model.uploadedFileUrl = downloadUrls.first;
                                });
                              } else {
                                safeSetState(() {});
                                return;
                              }
                            }

                            await universityProfileCopyCopyUniversityRecord!
                                .reference
                                .update(createUniversityRecordData(
                              profilePicture: _model.uploadedFileUrl,
                            ));
                            _model.edit = true;
                            safeSetState(() {});
                          },
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              70.0, 0.0, 70.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Text(
                                'اسم الجامعة:',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 250.0,
                          child: TextFormField(
                            controller: _model.uninameTextController ??=
                                TextEditingController(
                              text: universityProfileCopyCopyUniversityRecord
                                  ?.uniName,
                            ),
                            focusNode: _model.uninameFocusNode,
                            onChanged: (_) => EasyDebounce.debounce(
                              '_model.uninameTextController',
                              Duration(milliseconds: 0),
                              () async {
                                _model.edit = true;
                                safeSetState(() {});
                              },
                            ),
                            autofocus: false,
                            autofillHints: [AutofillHints.email],
                            textInputAction: TextInputAction.next,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: '29LTAzer_masarFont',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0x00000000),
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: '29LTAzer_masarFont',
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                            cursorColor:
                                FlutterFlowTheme.of(context).primaryText,
                            validator: _model.uninameTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Builder(
                          builder: (context) {
                            if (_model.nameUsed == true) {
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    70.0, 0.0, 70.0, 0.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Text(
                                      'اسم الجامعة مستخدم بالفعل!',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            color: FlutterFlowTheme.of(context)
                                                .error,
                                            fontSize: 11.0,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                  ],
                                ),
                              );
                            } else {
                              return Container(
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                ),
                              );
                            }
                          },
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              70.0, 0.0, 70.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 20.0, 0.0, 5.0),
                                child: Text(
                                  'وصف الجامعة:',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 250.0,
                          child: TextFormField(
                            controller: _model.descEditTextController ??=
                                TextEditingController(
                              text: universityProfileCopyCopyUniversityRecord
                                  ?.description,
                            ),
                            focusNode: _model.descEditFocusNode,
                            onChanged: (_) => EasyDebounce.debounce(
                              '_model.descEditTextController',
                              Duration(milliseconds: 0),
                              () async {
                                _model.edit = true;
                                safeSetState(() {});
                              },
                            ),
                            autofocus: false,
                            autofillHints: [AutofillHints.email],
                            textInputAction: TextInputAction.next,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: '29LTAzer_masarFont',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: '29LTAzer_masarFont',
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                            maxLength: 50,
                            maxLengthEnforcement: MaxLengthEnforcement.enforced,
                            cursorColor:
                                FlutterFlowTheme.of(context).primaryText,
                            validator: _model.descEditTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              70.0, 0.0, 70.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 20.0, 0.0, 5.0),
                                child: Text(
                                  'الموقع الإلكتروني:',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 250.0,
                          child: TextFormField(
                            controller: _model.websiteEditTextController ??=
                                TextEditingController(
                              text: universityProfileCopyCopyUniversityRecord
                                  ?.website,
                            ),
                            focusNode: _model.websiteEditFocusNode,
                            onChanged: (_) => EasyDebounce.debounce(
                              '_model.websiteEditTextController',
                              Duration(milliseconds: 0),
                              () async {
                                _model.edit = true;
                                safeSetState(() {});
                              },
                            ),
                            autofocus: false,
                            autofillHints: [AutofillHints.email],
                            textInputAction: TextInputAction.next,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: '29LTAzer_masarFont',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: '29LTAzer_masarFont',
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                            cursorColor:
                                FlutterFlowTheme.of(context).primaryText,
                            validator: _model.websiteEditTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              70.0, 0.0, 70.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 15.0, 0.0, 0.0),
                                child: Text(
                                  'بريد التواصل:',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 250.0,
                          child: TextFormField(
                            controller: _model.contactEditTextController ??=
                                TextEditingController(
                              text: universityProfileCopyCopyUniversityRecord
                                  ?.contactEmail,
                            ),
                            focusNode: _model.contactEditFocusNode,
                            onChanged: (_) => EasyDebounce.debounce(
                              '_model.contactEditTextController',
                              Duration(milliseconds: 0),
                              () async {
                                _model.edit = true;
                                safeSetState(() {});
                              },
                            ),
                            autofocus: false,
                            autofillHints: [AutofillHints.email],
                            textInputAction: TextInputAction.next,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: '29LTAzer_masarFont',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0x00000000),
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: '29LTAzer_masarFont',
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                            cursorColor:
                                FlutterFlowTheme.of(context).primaryText,
                            validator: _model.contactEditTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              70.0, 0.0, 70.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 15.0, 0.0, 0.0),
                                child: Text(
                                  'حساب X:',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 250.0,
                          child: TextFormField(
                            controller: _model.xEditTextController ??=
                                TextEditingController(
                              text: universityProfileCopyCopyUniversityRecord
                                  ?.xAccount,
                            ),
                            focusNode: _model.xEditFocusNode,
                            onChanged: (_) => EasyDebounce.debounce(
                              '_model.xEditTextController',
                              Duration(milliseconds: 0),
                              () async {
                                _model.edit = true;
                                safeSetState(() {});
                              },
                            ),
                            autofocus: false,
                            autofillHints: [AutofillHints.email],
                            textInputAction: TextInputAction.next,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: '29LTAzer_masarFont',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0x00000000),
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: '29LTAzer_masarFont',
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                            cursorColor:
                                FlutterFlowTheme.of(context).primaryText,
                            validator: _model.xEditTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Divider(
                          height: 44.0,
                          thickness: 1.0,
                          indent: 24.0,
                          endIndent: 24.0,
                          color: FlutterFlowTheme.of(context).alternate,
                        ).animateOnPageLoad(
                            animationsMap['dividerOnPageLoadAnimation']!),
                        Builder(
                          builder: (context) => Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                30.0, 16.0, 30.0, 0.0),
                            child: FFButtonWidget(
                              onPressed: () async {
                                var _shouldSetState = false;
                                safeSetState(() {
                                  _model.uninameTextController?.text =
                                      functions.processInput(
                                          _model.uninameTextController.text)!;
                                });
                                safeSetState(() {
                                  _model.descEditTextController?.text =
                                      functions.processInput(
                                          _model.descEditTextController.text)!;
                                });
                                safeSetState(() {
                                  _model.websiteEditTextController?.text =
                                      functions.processInput(_model
                                          .websiteEditTextController.text)!;
                                });
                                safeSetState(() {
                                  _model.contactEditTextController?.text =
                                      functions.processInput(_model
                                          .contactEditTextController.text)!;
                                });
                                safeSetState(() {
                                  _model.xEditTextController?.text =
                                      functions.processInput(
                                          _model.xEditTextController.text)!;
                                });
                                await Future.wait([
                                  Future(() async {
                                    _model.uniEdit = true;
                                    if (_model.formKey.currentState == null ||
                                        !_model.formKey.currentState!
                                            .validate()) {
                                      _model.uniEdit = false;
                                    }
                                    _shouldSetState = true;
                                  }),
                                  Future(() async {
                                    _model.uniName =
                                        await queryUniversityRecordCount(
                                      queryBuilder: (universityRecord) =>
                                          universityRecord
                                              .where(
                                                'University',
                                                isEqualTo: currentUserReference,
                                              )
                                              .where(
                                                'UniName',
                                                isEqualTo: _model
                                                    .uninameTextController.text,
                                              ),
                                    );
                                    _shouldSetState = true;
                                    if (_model.uniName != 1) {
                                      _model.uniused =
                                          await queryUniversityRecordCount(
                                        queryBuilder: (universityRecord) =>
                                            universityRecord.where(
                                          'UniName',
                                          isEqualTo:
                                              _model.uninameTextController.text,
                                        ),
                                      );
                                      _shouldSetState = true;
                                      if (_model.uniused! >= 1) {
                                        _model.nameUsed = true;
                                        safeSetState(() {});
                                      } else {
                                        _model.nameUsed = false;
                                        safeSetState(() {});
                                      }
                                    }
                                  }),
                                ]);
                                if ((_model.uniEdit == true) &&
                                    ((_model.nameUsed != true) ||
                                        (_model.uniName == 1))) {
                                  await Future.wait([
                                    Future(() async {
                                      await universityProfileCopyCopyUniversityRecord!
                                          .reference
                                          .update(createUniversityRecordData(
                                        uniName:
                                            _model.uninameTextController.text,
                                      ));
                                    }),
                                    Future(() async {
                                      await universityProfileCopyCopyUniversityRecord!
                                          .reference
                                          .update(createUniversityRecordData(
                                        description:
                                            _model.descEditTextController.text,
                                      ));
                                    }),
                                    Future(() async {
                                      await universityProfileCopyCopyUniversityRecord!
                                          .reference
                                          .update(createUniversityRecordData(
                                        website: _model
                                            .websiteEditTextController.text,
                                      ));
                                    }),
                                    Future(() async {
                                      await universityProfileCopyCopyUniversityRecord!
                                          .reference
                                          .update(createUniversityRecordData(
                                        contactEmail: _model
                                            .contactEditTextController.text,
                                      ));
                                    }),
                                    Future(() async {
                                      await universityProfileCopyCopyUniversityRecord!
                                          .reference
                                          .update(createUniversityRecordData(
                                        xAccount:
                                            _model.xEditTextController.text,
                                      ));
                                    }),
                                  ]);
                                  if (_model.edit == true) {
                                    await showDialog(
                                      context: context,
                                      builder: (dialogContext) {
                                        return Dialog(
                                          elevation: 0,
                                          insetPadding: EdgeInsets.zero,
                                          backgroundColor: Colors.transparent,
                                          alignment: AlignmentDirectional(
                                                  0.0, 0.0)
                                              .resolve(
                                                  Directionality.of(context)),
                                          child: WebViewAware(
                                            child: GestureDetector(
                                              onTap: () {
                                                FocusScope.of(dialogContext)
                                                    .unfocus();
                                                FocusManager
                                                    .instance.primaryFocus
                                                    ?.unfocus();
                                              },
                                              child:
                                                  EditStudentSuccesfullyCopyWidget(),
                                            ),
                                          ),
                                        );
                                      },
                                    );
                                  }

                                  context.pushNamed(
                                    UniversityProfileWidget.routeName,
                                    queryParameters: {
                                      'uni': serializeParam(
                                        widget!.uni,
                                        ParamType.Document,
                                      ),
                                    }.withoutNulls,
                                    extra: <String, dynamic>{
                                      'uni': widget!.uni,
                                    },
                                  );

                                  _model.edit = false;
                                  safeSetState(() {});
                                } else {
                                  if (_shouldSetState) safeSetState(() {});
                                  return;
                                }

                                if (_shouldSetState) safeSetState(() {});
                              },
                              text: 'حفظ',
                              options: FFButtonOptions(
                                width: 110.0,
                                height: 44.0,
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                iconPadding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                color: FlutterFlowTheme.of(context).logoColor2,
                                textStyle: FlutterFlowTheme.of(context)
                                    .bodyLarge
                                    .override(
                                      fontFamily: '29LTAzer_masarFont',
                                      color: FlutterFlowTheme.of(context)
                                          .primaryBackground,
                                      fontSize: 18.0,
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                                elevation: 0.0,
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                            ),
                          ),
                        ),
                        Builder(
                          builder: (context) => Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                30.0, 20.0, 30.0, 0.0),
                            child: FFButtonWidget(
                              onPressed: () async {
                                await showDialog(
                                  context: context,
                                  builder: (dialogContext) {
                                    return Dialog(
                                      elevation: 0,
                                      insetPadding: EdgeInsets.zero,
                                      backgroundColor: Colors.transparent,
                                      alignment: AlignmentDirectional(0.0, 0.0)
                                          .resolve(Directionality.of(context)),
                                      child: WebViewAware(
                                        child: GestureDetector(
                                          onTap: () {
                                            FocusScope.of(dialogContext)
                                                .unfocus();
                                            FocusManager.instance.primaryFocus
                                                ?.unfocus();
                                          },
                                          child: CancelEditUniWidget(
                                            uni: widget!.uni!,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                              text: 'إلغاء',
                              options: FFButtonOptions(
                                width: 110.0,
                                height: 44.0,
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                iconPadding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                color: Color(0xFFC52C38),
                                textStyle: FlutterFlowTheme.of(context)
                                    .bodyLarge
                                    .override(
                                      fontFamily: '29LTAzer_masarFont',
                                      color: FlutterFlowTheme.of(context)
                                          .primaryBackground,
                                      fontSize: 18.0,
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                                elevation: 0.0,
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                            ).animateOnPageLoad(
                                animationsMap['buttonOnPageLoadAnimation']!),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
