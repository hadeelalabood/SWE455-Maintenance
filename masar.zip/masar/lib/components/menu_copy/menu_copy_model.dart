import '/backend/backend.dart';
import '/components/college_dele/college_dele_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'menu_copy_widget.dart' show MenuCopyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class MenuCopyModel extends FlutterFlowModel<MenuCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
