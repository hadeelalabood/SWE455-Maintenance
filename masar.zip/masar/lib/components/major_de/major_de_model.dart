import '/backend/backend.dart';
import '/components/major_deletesuccess/major_deletesuccess_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'major_de_widget.dart' show MajorDeWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class MajorDeModel extends FlutterFlowModel<MajorDeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
