import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/notification_alert/notification_alert_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'registration_notification_model.dart';
export 'registration_notification_model.dart';

class RegistrationNotificationWidget extends StatefulWidget {
  const RegistrationNotificationWidget({
    super.key,
    required this.registration,
  });

  final RegistrationDatesRecord? registration;

  @override
  State<RegistrationNotificationWidget> createState() =>
      _RegistrationNotificationWidgetState();
}

class _RegistrationNotificationWidgetState
    extends State<RegistrationNotificationWidget> {
  late RegistrationNotificationModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => RegistrationNotificationModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (getCurrentTimestamp < widget!.registration!.startTime!) {
        _model.empty = await queryNotificationsRecordCount(
          queryBuilder: (notificationsRecord) => notificationsRecord
              .where(
                'user',
                isEqualTo: currentUserReference,
              )
              .where(
                'regDate',
                isEqualTo: widget!.registration?.reference,
              ),
        );
        if (_model.empty == 0) {
          var notificationsRecordReference =
              NotificationsRecord.collection.doc();
          await notificationsRecordReference.set(createNotificationsRecordData(
            user: currentUserReference,
            regDate: widget!.registration?.reference,
            notification: false,
          ));
          _model.create = NotificationsRecord.getDocumentFromData(
              createNotificationsRecordData(
                user: currentUserReference,
                regDate: widget!.registration?.reference,
                notification: false,
              ),
              notificationsRecordReference);
        }
      }
      _model.update = await queryNotificationsRecordOnce(
        queryBuilder: (notificationsRecord) => notificationsRecord
            .where(
              'user',
              isEqualTo: currentUserReference,
            )
            .where(
              'regDate',
              isEqualTo: widget!.registration?.reference,
            ),
        singleRecord: true,
      ).then((s) => s.firstOrNull);
      safeSetState(() {
        _model.switchValue = _model.update!.notification;
      });
    });

    _model.switchValue = false;
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.0),
        border: Border.all(
          color: FlutterFlowTheme.of(context).alternate,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(10.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Builder(
              builder: (context) {
                if (getCurrentTimestamp < widget!.registration!.startTime!) {
                  return Align(
                    alignment: AlignmentDirectional(0.0, -1.0),
                    child: Container(
                      width: 80.0,
                      height: 40.0,
                      decoration: BoxDecoration(
                        color: Color(0xFFFFB74D),
                        borderRadius: BorderRadius.circular(40.0),
                        shape: BoxShape.rectangle,
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Text(
                          'قريبة',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: '29LTAzer_masarFont',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    fontSize: 20.0,
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                        ),
                      ),
                    ),
                  );
                } else if ((getCurrentTimestamp >=
                        widget!.registration!.startTime!) &&
                    (getCurrentTimestamp <= widget!.registration!.endTime!)) {
                  return Align(
                    alignment: AlignmentDirectional(0.0, -1.0),
                    child: Container(
                      width: 80.0,
                      height: 40.0,
                      decoration: BoxDecoration(
                        color: Color(0xFF66BB6A),
                        borderRadius: BorderRadius.circular(40.0),
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Text(
                          'مفتوحة',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: '29LTAzer_masarFont',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    fontSize: 20.0,
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                        ),
                      ),
                    ),
                  );
                } else {
                  return Align(
                    alignment: AlignmentDirectional(0.0, -1.0),
                    child: Container(
                      width: 80.0,
                      height: 40.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).error,
                        borderRadius: BorderRadius.circular(40.0),
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Text(
                          'مغلقة',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: '29LTAzer_masarFont',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    fontSize: 20.0,
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                        ),
                      ),
                    ),
                  );
                }
              },
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Flexible(
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 10.0),
                    child: Text(
                      valueOrDefault<String>(
                        widget!.registration?.description,
                        'لايوجد',
                      ),
                      style: FlutterFlowTheme.of(context).bodyLarge.override(
                            fontFamily: '29LTAzer_masarFont',
                            fontSize: 20.0,
                            letterSpacing: 0.0,
                            useGoogleFonts: false,
                          ),
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  'بداية التسجيل: ',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: '29LTAzer_masarFont',
                        fontSize: 20.0,
                        letterSpacing: 0.0,
                        useGoogleFonts: false,
                      ),
                ),
                Text(
                  valueOrDefault<String>(
                    dateTimeFormat(
                      "h:mm a , d MMMM y ",
                      widget!.registration?.startTime,
                      locale: FFLocalizations.of(context).languageCode,
                    ),
                    'لايوجد',
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: '29LTAzer_masarFont',
                        fontSize: 20.0,
                        letterSpacing: 0.0,
                        useGoogleFonts: false,
                      ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  'نهاية التسجيل: ',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: '29LTAzer_masarFont',
                        fontSize: 20.0,
                        letterSpacing: 0.0,
                        useGoogleFonts: false,
                      ),
                ),
                Text(
                  valueOrDefault<String>(
                    dateTimeFormat(
                      "h:mm a , d MMMM y ",
                      widget!.registration?.endTime,
                      locale: FFLocalizations.of(context).languageCode,
                    ),
                    'لايوجد',
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: '29LTAzer_masarFont',
                        fontSize: 20.0,
                        letterSpacing: 0.0,
                        useGoogleFonts: false,
                      ),
                ),
              ],
            ),
            if (getCurrentTimestamp <
                functions.subtractTime(widget!.registration!.startTime!))
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'تذكير قبل موعد التسجيل بيوم:',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: '29LTAzer_masarFont',
                            fontSize: 20.0,
                            letterSpacing: 0.0,
                            useGoogleFonts: false,
                          ),
                    ),
                    Builder(
                      builder: (context) => Switch.adaptive(
                        value: _model.switchValue!,
                        onChanged: (newValue) async {
                          safeSetState(() => _model.switchValue = newValue!);
                          if (newValue!) {
                            _model.idNotification =
                                await actions.scheduleReminder(
                              widget!.registration!.universityName,
                              widget!.registration!.description,
                              widget!.registration!.startTime!,
                              true,
                            );
                            if (_model.idNotification != null) {
                              await showDialog(
                                context: context,
                                builder: (dialogContext) {
                                  return Dialog(
                                    elevation: 0,
                                    insetPadding: EdgeInsets.zero,
                                    backgroundColor: Colors.transparent,
                                    alignment: AlignmentDirectional(-0.0, 0.0)
                                        .resolve(Directionality.of(context)),
                                    child: WebViewAware(
                                      child: NotificationAlertWidget(
                                        message: 'تم تفعيل التذكير',
                                        reminder: true,
                                      ),
                                    ),
                                  );
                                },
                              );
                            }

                            await _model.update!.reference
                                .update(createNotificationsRecordData(
                              id: _model.idNotification,
                              notification: true,
                            ));
                            safeSetState(() {
                              _model.switchValue = true;
                            });

                            safeSetState(() {});
                          } else {
                            _model.cancel = await actions.cancelReminder(
                              _model.idNotification!,
                            );
                            if (_model.cancel == true) {
                              await showDialog(
                                context: context,
                                builder: (dialogContext) {
                                  return Dialog(
                                    elevation: 0,
                                    insetPadding: EdgeInsets.zero,
                                    backgroundColor: Colors.transparent,
                                    alignment: AlignmentDirectional(-0.0, 0.0)
                                        .resolve(Directionality.of(context)),
                                    child: WebViewAware(
                                      child: NotificationAlertWidget(
                                        message: 'تم الغاء التذكير',
                                        reminder: false,
                                      ),
                                    ),
                                  );
                                },
                              );
                            }

                            await _model.update!.reference
                                .update(createNotificationsRecordData(
                              notification: false,
                            ));
                            safeSetState(() {
                              _model.switchValue = false;
                            });

                            safeSetState(() {});
                          }
                        },
                        activeColor: FlutterFlowTheme.of(context).logoColor2,
                        activeTrackColor:
                            FlutterFlowTheme.of(context).logoColor2,
                        inactiveTrackColor:
                            FlutterFlowTheme.of(context).alternate,
                        inactiveThumbColor:
                            FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                    ),
                  ],
                ),
              ),
          ].divide(SizedBox(height: 5.0)),
        ),
      ),
    );
  }
}
