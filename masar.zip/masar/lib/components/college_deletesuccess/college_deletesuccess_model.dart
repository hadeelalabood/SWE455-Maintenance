import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'college_deletesuccess_widget.dart' show CollegeDeletesuccessWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CollegeDeletesuccessModel
    extends FlutterFlowModel<CollegeDeletesuccessWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
