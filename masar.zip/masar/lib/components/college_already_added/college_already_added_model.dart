import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'college_already_added_widget.dart' show CollegeAlreadyAddedWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CollegeAlreadyAddedModel
    extends FlutterFlowModel<CollegeAlreadyAddedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
