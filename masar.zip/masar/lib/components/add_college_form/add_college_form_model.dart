import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/college_added_successfully/college_added_successfully_widget.dart';
import '/components/college_already_added/college_already_added_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'add_college_form_widget.dart' show AddCollegeFormWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class AddCollegeFormModel extends FlutterFlowModel<AddCollegeFormWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  String? _textControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 30) {
      return 'ادخل اسم لا يتجاوز 30 خانة';
    }
    if (!RegExp('^كلية(?=.*[\\u0621-\\u064A])[\\u0621-\\u064A\\s]+\$')
        .hasMatch(val)) {
      return 'الرجاء ادخال الاسم بشكل صحيح\nيجب أن يبدأ بكلمة \"كلية\" و\n لايحتوي على ارقام او رموز \nويجب أن يكون باللغة العربية. ';
    }
    return null;
  }

  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  CollegesRecord? uniqueCollege;

  @override
  void initState(BuildContext context) {
    textControllerValidator = _textControllerValidator;
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
