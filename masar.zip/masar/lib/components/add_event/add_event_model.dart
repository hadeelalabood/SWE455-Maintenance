import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/event_added_successfully/event_added_successfully_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'add_event_widget.dart' show AddEventWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class AddEventModel extends FlutterFlowModel<AddEventWidget> {
  ///  Local state fields for this component.

  bool? error;

  bool? startTimeError;

  bool? endTimeError;

  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  String? _textController2Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 100) {
      return 'الوصف يجب أن لا يزيد عن 100 خانة.';
    }

    return null;
  }

  DateTime? datePicked1;
  DateTime? datePicked2;
  // Stores action output result for [Validate Form] action in Button widget.
  bool? form1;
  // Stores action output result for [Custom Action - eventTojson1] action in Button widget.
  dynamic? createdEvent;
  // Stores action output result for [Custom Action - addEventToCalendar1] action in Button widget.
  String? addEvent;

  @override
  void initState(BuildContext context) {
    textController2Validator = _textController2Validator;
  }

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();
  }
}
