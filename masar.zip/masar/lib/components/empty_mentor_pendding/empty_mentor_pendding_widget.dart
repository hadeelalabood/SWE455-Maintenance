import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'empty_mentor_pendding_model.dart';
export 'empty_mentor_pendding_model.dart';

class EmptyMentorPenddingWidget extends StatefulWidget {
  const EmptyMentorPenddingWidget({super.key});

  @override
  State<EmptyMentorPenddingWidget> createState() =>
      _EmptyMentorPenddingWidgetState();
}

class _EmptyMentorPenddingWidgetState extends State<EmptyMentorPenddingWidget> {
  late EmptyMentorPenddingModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyMentorPenddingModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'لا يوجد مرشد قيد الانتظار',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: '29LTAzer_masarFont',
                    letterSpacing: 0.0,
                    useGoogleFonts: false,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
