import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'gender_form_widget.dart' show GenderFormWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenderFormModel extends FlutterFlowModel<GenderFormWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for isMale widget.
  bool? isMaleValue;
  // State field(s) for isFemale widget.
  bool? isFemaleValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
