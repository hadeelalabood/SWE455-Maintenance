import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'empty_majors_model.dart';
export 'empty_majors_model.dart';

class EmptyMajorsWidget extends StatefulWidget {
  const EmptyMajorsWidget({super.key});

  @override
  State<EmptyMajorsWidget> createState() => _EmptyMajorsWidgetState();
}

class _EmptyMajorsWidgetState extends State<EmptyMajorsWidget> {
  late EmptyMajorsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyMajorsModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          'لا توجد تخصصات متاحة',
          style: FlutterFlowTheme.of(context).headlineMedium.override(
                fontFamily: '29LTAzer_masarFont',
                letterSpacing: 0.0,
                useGoogleFonts: false,
              ),
        ),
        Text(
          'الرجاء إضافة تخصص جديد',
          style: FlutterFlowTheme.of(context).labelMedium.override(
                fontFamily: '29LTAzer_masarFont',
                letterSpacing: 0.0,
                useGoogleFonts: false,
              ),
        ),
      ],
    );
  }
}
