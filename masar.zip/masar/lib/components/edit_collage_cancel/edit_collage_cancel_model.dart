import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'edit_collage_cancel_widget.dart' show EditCollageCancelWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditCollageCancelModel extends FlutterFlowModel<EditCollageCancelWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
