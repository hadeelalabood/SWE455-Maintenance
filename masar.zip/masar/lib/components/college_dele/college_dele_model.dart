import '/backend/backend.dart';
import '/components/college_deletesuccess/college_deletesuccess_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'college_dele_widget.dart' show CollegeDeleWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class CollegeDeleModel extends FlutterFlowModel<CollegeDeleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
