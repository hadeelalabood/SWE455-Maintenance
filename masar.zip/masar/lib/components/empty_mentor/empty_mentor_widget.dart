import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'empty_mentor_model.dart';
export 'empty_mentor_model.dart';

class EmptyMentorWidget extends StatefulWidget {
  const EmptyMentorWidget({super.key});

  @override
  State<EmptyMentorWidget> createState() => _EmptyMentorWidgetState();
}

class _EmptyMentorWidgetState extends State<EmptyMentorWidget> {
  late EmptyMentorModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyMentorModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'لا يوجد مرشدين',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: '29LTAzer_masarFont',
                    letterSpacing: 0.0,
                    useGoogleFonts: false,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
