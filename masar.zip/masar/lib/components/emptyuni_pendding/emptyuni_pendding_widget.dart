import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'emptyuni_pendding_model.dart';
export 'emptyuni_pendding_model.dart';

class EmptyuniPenddingWidget extends StatefulWidget {
  const EmptyuniPenddingWidget({super.key});

  @override
  State<EmptyuniPenddingWidget> createState() => _EmptyuniPenddingWidgetState();
}

class _EmptyuniPenddingWidgetState extends State<EmptyuniPenddingWidget> {
  late EmptyuniPenddingModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyuniPenddingModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'لا يوجد جامعة قيد الانتظار',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: '29LTAzer_masarFont',
                    letterSpacing: 0.0,
                    useGoogleFonts: false,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
