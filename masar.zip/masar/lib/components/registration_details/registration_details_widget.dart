import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/notification_alert/notification_alert_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'registration_details_model.dart';
export 'registration_details_model.dart';

class RegistrationDetailsWidget extends StatefulWidget {
  const RegistrationDetailsWidget({
    super.key,
    this.registration,
    this.notification,
    required this.status,
  });

  final RegistrationDatesRecord? registration;
  final NotificationsRecord? notification;
  final String? status;

  @override
  State<RegistrationDetailsWidget> createState() =>
      _RegistrationDetailsWidgetState();
}

class _RegistrationDetailsWidgetState extends State<RegistrationDetailsWidget> {
  late RegistrationDetailsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => RegistrationDetailsModel());

    _model.switchValue = widget!.notification!.notification;
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Container(
        width: 315.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Padding(
          padding: EdgeInsets.all(15.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      await widget!.notification!.reference
                          .update(createNotificationsRecordData(
                        notification: _model.switchValue,
                      ));
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.close,
                      color: FlutterFlowTheme.of(context).primaryText,
                      size: 24.0,
                    ),
                  ),
                  Flexible(
                    child: Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Text(
                        valueOrDefault<String>(
                          widget!.registration?.universityName,
                          'لا يوجد',
                        ),
                        style: FlutterFlowTheme.of(context).titleLarge.override(
                              fontFamily: '29LTAzer_masarFont',
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Text(
                      'الوصف: ',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: '29LTAzer_masarFont',
                            fontSize: 20.0,
                            letterSpacing: 0.0,
                            useGoogleFonts: false,
                          ),
                    ),
                    Flexible(
                      child: Text(
                        valueOrDefault<String>(
                          widget!.registration?.description,
                          'لا يوجد',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: '29LTAzer_masarFont',
                              fontSize: 20.0,
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'بداية التسجيل: ',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: '29LTAzer_masarFont',
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                          useGoogleFonts: false,
                        ),
                  ),
                  Text(
                    dateTimeFormat(
                      "h:mm a , d MMMM y ",
                      widget!.registration!.startTime!,
                      locale: FFLocalizations.of(context).languageCode,
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: '29LTAzer_masarFont',
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                          useGoogleFonts: false,
                        ),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'نهاية التسجيل: ',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: '29LTAzer_masarFont',
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                          useGoogleFonts: false,
                        ),
                  ),
                  Text(
                    dateTimeFormat(
                      "h:mm a , d MMMM y ",
                      widget!.registration!.endTime!,
                      locale: FFLocalizations.of(context).languageCode,
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: '29LTAzer_masarFont',
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                          useGoogleFonts: false,
                        ),
                  ),
                ],
              ),
              if ((widget!.status == 'soon') &&
                  (getCurrentTimestamp <
                      functions.subtractTime(widget!.registration!.startTime!)))
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'تذكير قبل موعد التسجيل بيوم:',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: '29LTAzer_masarFont',
                              fontSize: 20.0,
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                      ),
                      Builder(
                        builder: (context) => Switch.adaptive(
                          value: _model.switchValue!,
                          onChanged: (newValue) async {
                            safeSetState(() => _model.switchValue = newValue!);
                            if (newValue!) {
                              _model.idNotification =
                                  await actions.scheduleReminder(
                                widget!.registration!.universityName,
                                widget!.registration!.description,
                                widget!.registration!.startTime!,
                                true,
                              );
                              if (_model.idNotification != null) {
                                await showDialog(
                                  context: context,
                                  builder: (dialogContext) {
                                    return Dialog(
                                      elevation: 0,
                                      insetPadding: EdgeInsets.zero,
                                      backgroundColor: Colors.transparent,
                                      alignment: AlignmentDirectional(-0.0, 0.0)
                                          .resolve(Directionality.of(context)),
                                      child: WebViewAware(
                                        child: NotificationAlertWidget(
                                          message: 'تم تفعيل التذكير',
                                          reminder: true,
                                        ),
                                      ),
                                    );
                                  },
                                );
                              }

                              await widget!.notification!.reference
                                  .update(createNotificationsRecordData(
                                id: _model.idNotification,
                              ));

                              safeSetState(() {});
                            } else {
                              _model.cancel = await actions.cancelReminder(
                                _model.idNotification!,
                              );
                              if (_model.cancel == true) {
                                await showDialog(
                                  context: context,
                                  builder: (dialogContext) {
                                    return Dialog(
                                      elevation: 0,
                                      insetPadding: EdgeInsets.zero,
                                      backgroundColor: Colors.transparent,
                                      alignment: AlignmentDirectional(-0.0, 0.0)
                                          .resolve(Directionality.of(context)),
                                      child: WebViewAware(
                                        child: NotificationAlertWidget(
                                          message: 'تم الغاء التذكير',
                                          reminder: false,
                                        ),
                                      ),
                                    );
                                  },
                                );
                              }

                              safeSetState(() {});
                            }
                          },
                          activeColor: FlutterFlowTheme.of(context).logoColor2,
                          activeTrackColor:
                              FlutterFlowTheme.of(context).logoColor2,
                          inactiveTrackColor:
                              FlutterFlowTheme.of(context).alternate,
                          inactiveThumbColor:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                      ),
                    ].divide(SizedBox(width: 10.0)),
                  ),
                ),
            ].divide(SizedBox(height: 20.0)),
          ),
        ),
      ),
    );
  }
}
