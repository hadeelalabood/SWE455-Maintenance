import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/notification_alert/notification_alert_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'registration_details_widget.dart' show RegistrationDetailsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class RegistrationDetailsModel
    extends FlutterFlowModel<RegistrationDetailsWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Switch widget.
  bool? switchValue;
  // Stores action output result for [Custom Action - scheduleReminder] action in Switch widget.
  int? idNotification;
  // Stores action output result for [Custom Action - cancelReminder] action in Switch widget.
  bool? cancel;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
