import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'major_added_successfully_model.dart';
export 'major_added_successfully_model.dart';

class MajorAddedSuccessfullyWidget extends StatefulWidget {
  const MajorAddedSuccessfullyWidget({super.key});

  @override
  State<MajorAddedSuccessfullyWidget> createState() =>
      _MajorAddedSuccessfullyWidgetState();
}

class _MajorAddedSuccessfullyWidgetState
    extends State<MajorAddedSuccessfullyWidget> {
  late MajorAddedSuccessfullyModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MajorAddedSuccessfullyModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(milliseconds: 1000));
      Navigator.pop(context);
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Container(
        width: 300.0,
        height: 150.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Align(
              alignment: AlignmentDirectional(-0.01, -1.01),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.asset(
                  'assets/images/8683794_(1).png',
                  width: 98.0,
                  height: 94.0,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Text(
              'تمت اضافة التخصص بنجاح',
              textAlign: TextAlign.center,
              style: FlutterFlowTheme.of(context).displaySmall.override(
                    fontFamily: '29LTAzer_masarFont',
                    color: FlutterFlowTheme.of(context).success,
                    fontSize: 23.0,
                    letterSpacing: 0.0,
                    useGoogleFonts: false,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
