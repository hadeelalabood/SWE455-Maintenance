import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'empty_uni_approve_model.dart';
export 'empty_uni_approve_model.dart';

class EmptyUniApproveWidget extends StatefulWidget {
  const EmptyUniApproveWidget({super.key});

  @override
  State<EmptyUniApproveWidget> createState() => _EmptyUniApproveWidgetState();
}

class _EmptyUniApproveWidgetState extends State<EmptyUniApproveWidget> {
  late EmptyUniApproveModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyUniApproveModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              'لا يوجد جامعة مقبولة',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: '29LTAzer_masarFont',
                    letterSpacing: 0.0,
                    useGoogleFonts: false,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
