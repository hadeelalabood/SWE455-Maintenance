import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'create_mentor_widget.dart' show CreateMentorWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateMentorModel extends FlutterFlowModel<CreateMentorWidget> {
  ///  Local state fields for this page.

  bool? matchPass = true;

  bool? pdfCheck = true;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for FirstName widget.
  FocusNode? firstNameFocusNode;
  TextEditingController? firstNameTextController;
  String? Function(BuildContext, String?)? firstNameTextControllerValidator;
  String? _firstNameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب';
    }

    if (val.length > 30) {
      return 'ادخل اسم لا يتجاوز 30 خانة';
    }
    if (!RegExp('^(?=.*\\S)([A-Za-z]+|[\\u0600-\\u06FF]+)\$').hasMatch(val)) {
      return '  ادخل اسم صحيح لا يحتوي على ارقام او رموز خاصة';
    }
    return null;
  }

  // State field(s) for LastName widget.
  FocusNode? lastNameFocusNode;
  TextEditingController? lastNameTextController;
  String? Function(BuildContext, String?)? lastNameTextControllerValidator;
  String? _lastNameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب';
    }

    if (val.length > 30) {
      return 'ادخل اسم لا يتجاوز 30 خانة';
    }
    if (!RegExp('^(?=.*\\S)([A-Za-z]+|[\\u0600-\\u06FF]+)\$').hasMatch(val)) {
      return '  ادخل اسم صحيح لا يحتوي على ارقام او رموز خاصة';
    }
    return null;
  }

  // State field(s) for uni widget.
  String? uniValue;
  FormFieldController<String>? uniValueController;
  // State field(s) for college widget.
  String? collegeValue;
  FormFieldController<String>? collegeValueController;
  // State field(s) for majorr widget.
  String? majorrValue;
  FormFieldController<String>? majorrValueController;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // Stores action output result for [Validate Form] action in Button widget.
  bool? mentorForm;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  MentorRecord? mentor;

  @override
  void initState(BuildContext context) {
    firstNameTextControllerValidator = _firstNameTextControllerValidator;
    lastNameTextControllerValidator = _lastNameTextControllerValidator;
  }

  @override
  void dispose() {
    firstNameFocusNode?.dispose();
    firstNameTextController?.dispose();

    lastNameFocusNode?.dispose();
    lastNameTextController?.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
