import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'create_university_copy2_widget.dart' show CreateUniversityCopy2Widget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateUniversityCopy2Model
    extends FlutterFlowModel<CreateUniversityCopy2Widget> {
  ///  Local state fields for this page.

  bool? matchPass = true;

  bool? imageNotEmpty;

  bool? nameUsed;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for uniName widget.
  FocusNode? uniNameFocusNode;
  TextEditingController? uniNameTextController;
  String? Function(BuildContext, String?)? uniNameTextControllerValidator;
  String? _uniNameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 50) {
      return 'ادخل اسم لا يتجاوز 50 خانة';
    }
    if (!RegExp('^[\\u0621-\\u064A\\s]+\$').hasMatch(val)) {
      return 'الرجاء ادخال الاسم بشكل صحيح  \nولايحتوي على ارقام او رموز\nويجب أن يكون باللغة العربية. ';
    }
    return null;
  }

  // State field(s) for uniDes widget.
  FocusNode? uniDesFocusNode;
  TextEditingController? uniDesTextController;
  String? Function(BuildContext, String?)? uniDesTextControllerValidator;
  String? _uniDesTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 150) {
      return 'الوصف يجب أن لا يزيد عن 150 خانة.';
    }

    return null;
  }

  // State field(s) for uniWebsite widget.
  FocusNode? uniWebsiteFocusNode;
  TextEditingController? uniWebsiteTextController;
  String? Function(BuildContext, String?)? uniWebsiteTextControllerValidator;
  String? _uniWebsiteTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 300) {
      return 'الرابط يجب أن لا يزيد عن 300 خانة.';
    }
    if (!RegExp(kTextValidatorWebsiteRegex).hasMatch(val)) {
      return 'الرجاء إدخال موقع إلكتروني صحيح.';
    }
    return null;
  }

  // State field(s) for uniEmail widget.
  FocusNode? uniEmailFocusNode;
  TextEditingController? uniEmailTextController;
  String? Function(BuildContext, String?)? uniEmailTextControllerValidator;
  String? _uniEmailTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 100) {
      return 'البريد الإلكتروني يجب أن لا يزيد عن 100 خانة.';
    }
    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return 'الرجاء إدخال بريد إلكتروني صحيح.';
    }
    return null;
  }

  // State field(s) for uniXAccount widget.
  FocusNode? uniXAccountFocusNode;
  TextEditingController? uniXAccountTextController;
  String? Function(BuildContext, String?)? uniXAccountTextControllerValidator;
  String? _uniXAccountTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 300) {
      return 'الرابط يجب أن لا يزيد عن 300 خانة.';
    }
    if (!RegExp(kTextValidatorWebsiteRegex).hasMatch(val)) {
      return 'الرجاء إدخال رابط X صحيح.';
    }
    return null;
  }

  // Stores action output result for [Validate Form] action in Button widget.
  bool? formUni;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  int? universitiesName;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UniversityRecord? uni;

  @override
  void initState(BuildContext context) {
    uniNameTextControllerValidator = _uniNameTextControllerValidator;
    uniDesTextControllerValidator = _uniDesTextControllerValidator;
    uniWebsiteTextControllerValidator = _uniWebsiteTextControllerValidator;
    uniEmailTextControllerValidator = _uniEmailTextControllerValidator;
    uniXAccountTextControllerValidator = _uniXAccountTextControllerValidator;
  }

  @override
  void dispose() {
    uniNameFocusNode?.dispose();
    uniNameTextController?.dispose();

    uniDesFocusNode?.dispose();
    uniDesTextController?.dispose();

    uniWebsiteFocusNode?.dispose();
    uniWebsiteTextController?.dispose();

    uniEmailFocusNode?.dispose();
    uniEmailTextController?.dispose();

    uniXAccountFocusNode?.dispose();
    uniXAccountTextController?.dispose();
  }
}
