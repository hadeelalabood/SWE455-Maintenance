import '/backend/backend.dart';
import '/components/pdf_view/pdf_view_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'mentor_view_major_details_widget.dart'
    show MentorViewMajorDetailsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class MentorViewMajorDetailsModel
    extends FlutterFlowModel<MentorViewMajorDetailsWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for majorName widget.
  FocusNode? majorNameFocusNode;
  TextEditingController? majorNameTextController;
  String? Function(BuildContext, String?)? majorNameTextControllerValidator;
  // State field(s) for majorDescription widget.
  FocusNode? majorDescriptionFocusNode;
  TextEditingController? majorDescriptionTextController;
  String? Function(BuildContext, String?)?
      majorDescriptionTextControllerValidator;
  // State field(s) for majorPreConditions widget.
  FocusNode? majorPreConditionsFocusNode;
  TextEditingController? majorPreConditionsTextController;
  String? Function(BuildContext, String?)?
      majorPreConditionsTextControllerValidator;
  // State field(s) for majorDuration widget.
  FocusNode? majorDurationFocusNode;
  TextEditingController? majorDurationTextController;
  String? Function(BuildContext, String?)? majorDurationTextControllerValidator;
  // State field(s) for mSchool widget.
  FocusNode? mSchoolFocusNode;
  TextEditingController? mSchoolTextController;
  String? Function(BuildContext, String?)? mSchoolTextControllerValidator;
  // State field(s) for mQudrat widget.
  FocusNode? mQudratFocusNode;
  TextEditingController? mQudratTextController;
  String? Function(BuildContext, String?)? mQudratTextControllerValidator;
  // State field(s) for mTahsili widget.
  FocusNode? mTahsiliFocusNode;
  TextEditingController? mTahsiliTextController;
  String? Function(BuildContext, String?)? mTahsiliTextControllerValidator;
  // State field(s) for mOtherTests widget.
  FocusNode? mOtherTestsFocusNode;
  TextEditingController? mOtherTestsTextController;
  String? Function(BuildContext, String?)? mOtherTestsTextControllerValidator;
  // State field(s) for mWeightPer widget.
  FocusNode? mWeightPerFocusNode;
  TextEditingController? mWeightPerTextController;
  String? Function(BuildContext, String?)? mWeightPerTextControllerValidator;
  // State field(s) for fSchool widget.
  FocusNode? fSchoolFocusNode;
  TextEditingController? fSchoolTextController;
  String? Function(BuildContext, String?)? fSchoolTextControllerValidator;
  // State field(s) for fQudrat widget.
  FocusNode? fQudratFocusNode;
  TextEditingController? fQudratTextController;
  String? Function(BuildContext, String?)? fQudratTextControllerValidator;
  // State field(s) for fTahsili widget.
  FocusNode? fTahsiliFocusNode;
  TextEditingController? fTahsiliTextController;
  String? Function(BuildContext, String?)? fTahsiliTextControllerValidator;
  // State field(s) for fOtherTests widget.
  FocusNode? fOtherTestsFocusNode;
  TextEditingController? fOtherTestsTextController;
  String? Function(BuildContext, String?)? fOtherTestsTextControllerValidator;
  // State field(s) for fWeightPer widget.
  FocusNode? fWeightPerFocusNode;
  TextEditingController? fWeightPerTextController;
  String? Function(BuildContext, String?)? fWeightPerTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    majorNameFocusNode?.dispose();
    majorNameTextController?.dispose();

    majorDescriptionFocusNode?.dispose();
    majorDescriptionTextController?.dispose();

    majorPreConditionsFocusNode?.dispose();
    majorPreConditionsTextController?.dispose();

    majorDurationFocusNode?.dispose();
    majorDurationTextController?.dispose();

    mSchoolFocusNode?.dispose();
    mSchoolTextController?.dispose();

    mQudratFocusNode?.dispose();
    mQudratTextController?.dispose();

    mTahsiliFocusNode?.dispose();
    mTahsiliTextController?.dispose();

    mOtherTestsFocusNode?.dispose();
    mOtherTestsTextController?.dispose();

    mWeightPerFocusNode?.dispose();
    mWeightPerTextController?.dispose();

    fSchoolFocusNode?.dispose();
    fSchoolTextController?.dispose();

    fQudratFocusNode?.dispose();
    fQudratTextController?.dispose();

    fTahsiliFocusNode?.dispose();
    fTahsiliTextController?.dispose();

    fOtherTestsFocusNode?.dispose();
    fOtherTestsTextController?.dispose();

    fWeightPerFocusNode?.dispose();
    fWeightPerTextController?.dispose();
  }
}
