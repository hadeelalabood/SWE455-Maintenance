import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/cancel_edit_mentor/cancel_edit_mentor_widget.dart';
import '/components/edit_student_succesfully/edit_student_succesfully_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'mentor_profile2_copy_widget.dart' show MentorProfile2CopyWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class MentorProfile2CopyModel
    extends FlutterFlowModel<MentorProfile2CopyWidget> {
  ///  Local state fields for this page.

  bool? edit;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for editFname widget.
  FocusNode? editFnameFocusNode;
  TextEditingController? editFnameTextController;
  String? Function(BuildContext, String?)? editFnameTextControllerValidator;
  String? _editFnameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 30) {
      return 'ادخل اسم لا يتجاوز 30 خانة';
    }
    if (!RegExp('^(?=.*\\S)([A-Za-z]+|[\\u0600-\\u06FF]+)\$').hasMatch(val)) {
      return '  ادخل اسم صحيح لا يحتوي على ارقام او رموز خاصة';
    }
    return null;
  }

  // State field(s) for editLname widget.
  FocusNode? editLnameFocusNode;
  TextEditingController? editLnameTextController;
  String? Function(BuildContext, String?)? editLnameTextControllerValidator;
  String? _editLnameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب!';
    }

    if (val.length > 30) {
      return 'ادخل اسم لا يتجاوز 30 خانة';
    }
    if (!RegExp('^(?=.*\\S)([A-Za-z]+|[\\u0600-\\u06FF]+)\$').hasMatch(val)) {
      return '  ادخل اسم صحيح لا يحتوي على ارقام او رموز خاصة';
    }
    return null;
  }

  // State field(s) for editmaj widget.
  FocusNode? editmajFocusNode;
  TextEditingController? editmajTextController;
  String? Function(BuildContext, String?)? editmajTextControllerValidator;
  String? _editmajTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'الحقل مطلوب';
    }

    if (val.length > 30) {
      return 'ادخل تخصص لا يتجاوز 30 خانة';
    }
    if (!RegExp('^[\\u0621-\\u064A\\s]+\$').hasMatch(val)) {
      return 'الرجاء ادخال التخصص بشكل صحيح  \nولايحتوي على ارقام او رموز\nويجب أن يكون باللغة العربية. ';
    }
    return null;
  }

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;

  @override
  void initState(BuildContext context) {
    editFnameTextControllerValidator = _editFnameTextControllerValidator;
    editLnameTextControllerValidator = _editLnameTextControllerValidator;
    editmajTextControllerValidator = _editmajTextControllerValidator;
  }

  @override
  void dispose() {
    editFnameFocusNode?.dispose();
    editFnameTextController?.dispose();

    editLnameFocusNode?.dispose();
    editLnameTextController?.dispose();

    editmajFocusNode?.dispose();
    editmajTextController?.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
