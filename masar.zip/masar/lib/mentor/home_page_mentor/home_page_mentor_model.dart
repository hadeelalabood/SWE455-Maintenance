import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/empty_chat/empty_chat_widget.dart';
import '/components/mentor_nav_bar/mentor_nav_bar_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'home_page_mentor_widget.dart' show HomePageMentorWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageMentorModel extends FlutterFlowModel<HomePageMentorWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for MentorNavBar component.
  late MentorNavBarModel mentorNavBarModel;

  @override
  void initState(BuildContext context) {
    mentorNavBarModel = createModel(context, () => MentorNavBarModel());
  }

  @override
  void dispose() {
    mentorNavBarModel.dispose();
  }
}
