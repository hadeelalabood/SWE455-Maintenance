import '/backend/backend.dart';
import '/components/empty_majors_student/empty_majors_student_widget.dart';
import '/components/major_copy/major_copy_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mentor_view_major_model.dart';
export 'mentor_view_major_model.dart';

class MentorViewMajorWidget extends StatefulWidget {
  const MentorViewMajorWidget({
    super.key,
    required this.college,
    required this.uni,
  });

  final CollegesRecord? college;
  final UniversityRecord? uni;

  static String routeName = 'MentorViewMajor';
  static String routePath = '/mentorViewMajor';

  @override
  State<MentorViewMajorWidget> createState() => _MentorViewMajorWidgetState();
}

class _MentorViewMajorWidgetState extends State<MentorViewMajorWidget> {
  late MentorViewMajorModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MentorViewMajorModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<CollegesRecord>(
      stream: CollegesRecord.getDocument(widget!.college!.reference),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).alternate,
                  ),
                ),
              ),
            ),
          );
        }

        final mentorViewMajorCollegesRecord = snapshot.data!;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).logoColor2,
              automaticallyImplyLeading: false,
              leading: FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 30.0,
                borderWidth: 1.0,
                buttonSize: 60.0,
                icon: Icon(
                  Icons.arrow_back_rounded,
                  color: Colors.white,
                  size: 30.0,
                ),
                onPressed: () async {
                  context.pop();
                },
              ),
              title: Text(
                valueOrDefault<String>(
                  widget!.college?.collegeName,
                  'name',
                ),
                style: FlutterFlowTheme.of(context).headlineMedium.override(
                      fontFamily: '29LTAzer_masarFont',
                      color: Colors.white,
                      fontSize: 30.0,
                      letterSpacing: 0.0,
                      useGoogleFonts: false,
                    ),
              ),
              actions: [],
              centerTitle: true,
              elevation: 2.0,
            ),
            body: SafeArea(
              top: true,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Flexible(
                    flex: 9,
                    child: Align(
                      alignment: AlignmentDirectional(0.0, -1.0),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            15.0, 30.0, 15.0, 0.0),
                        child: StreamBuilder<List<MajorsRecord>>(
                          stream: queryMajorsRecord(
                            queryBuilder: (majorsRecord) => majorsRecord
                                .where(
                                  'College',
                                  isEqualTo:
                                      mentorViewMajorCollegesRecord.reference,
                                )
                                .orderBy('MajorName'),
                          ),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).alternate,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<MajorsRecord> listViewMajorsRecordList =
                                snapshot.data!;
                            if (listViewMajorsRecordList.isEmpty) {
                              return EmptyMajorsStudentWidget();
                            }

                            return ListView.separated(
                              padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              itemCount: listViewMajorsRecordList.length,
                              separatorBuilder: (_, __) =>
                                  SizedBox(height: 12.0),
                              itemBuilder: (context, listViewIndex) {
                                final listViewMajorsRecord =
                                    listViewMajorsRecordList[listViewIndex];
                                return Align(
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      context.pushNamed(
                                        MentorViewMajorDetailsWidget.routeName,
                                        queryParameters: {
                                          'majorDoc': serializeParam(
                                            listViewMajorsRecord,
                                            ParamType.Document,
                                          ),
                                          'uni': serializeParam(
                                            widget!.uni,
                                            ParamType.Document,
                                          ),
                                          'collage': serializeParam(
                                            widget!.college,
                                            ParamType.Document,
                                          ),
                                        }.withoutNulls,
                                        extra: <String, dynamic>{
                                          'majorDoc': listViewMajorsRecord,
                                          'uni': widget!.uni,
                                          'collage': widget!.college,
                                        },
                                      );
                                    },
                                    child: MajorCopyWidget(
                                      key: Key(
                                          'Keygf1_${listViewIndex}_of_${listViewMajorsRecordList.length}'),
                                      majorsDoc: listViewMajorsRecord,
                                      uni: widget!.uni!,
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
