import '/backend/backend.dart';
import '/components/empty_majors_student/empty_majors_student_widget.dart';
import '/components/major_copy/major_copy_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'mentor_view_major_widget.dart' show MentorViewMajorWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MentorViewMajorModel extends FlutterFlowModel<MentorViewMajorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
