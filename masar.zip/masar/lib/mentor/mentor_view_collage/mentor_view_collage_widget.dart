import '/backend/backend.dart';
import '/components/empty_colleges_student/empty_colleges_student_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mentor_view_collage_model.dart';
export 'mentor_view_collage_model.dart';

class MentorViewCollageWidget extends StatefulWidget {
  const MentorViewCollageWidget({
    super.key,
    required this.uni,
  });

  final UniversityRecord? uni;

  static String routeName = 'MentorViewCollage';
  static String routePath = '/mentorViewCollage';

  @override
  State<MentorViewCollageWidget> createState() =>
      _MentorViewCollageWidgetState();
}

class _MentorViewCollageWidgetState extends State<MentorViewCollageWidget> {
  late MentorViewCollageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MentorViewCollageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).logoColor2,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'الكليات',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: '29LTAzer_masarFont',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                  useGoogleFonts: false,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                flex: 10,
                child: Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(35.0, 35.0, 35.0, 0.0),
                    child: StreamBuilder<List<CollegesRecord>>(
                      stream: queryCollegesRecord(
                        queryBuilder: (collegesRecord) => collegesRecord
                            .where(
                              'uniname',
                              isEqualTo: widget!.uni?.reference,
                            )
                            .orderBy('CollegeName'),
                      ),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).alternate,
                                ),
                              ),
                            ),
                          );
                        }
                        List<CollegesRecord> gridViewCollegesRecordList =
                            snapshot.data!;
                        if (gridViewCollegesRecordList.isEmpty) {
                          return Center(
                            child: EmptyCollegesStudentWidget(),
                          );
                        }

                        return GridView.builder(
                          padding: EdgeInsets.fromLTRB(
                            0,
                            5.0,
                            0,
                            5.0,
                          ),
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 15.0,
                            mainAxisSpacing: 15.0,
                            childAspectRatio: 1.0,
                          ),
                          scrollDirection: Axis.vertical,
                          itemCount: gridViewCollegesRecordList.length,
                          itemBuilder: (context, gridViewIndex) {
                            final gridViewCollegesRecord =
                                gridViewCollegesRecordList[gridViewIndex];
                            return InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                context.pushNamed(
                                  MentorViewMajorWidget.routeName,
                                  queryParameters: {
                                    'college': serializeParam(
                                      gridViewCollegesRecord,
                                      ParamType.Document,
                                    ),
                                    'uni': serializeParam(
                                      widget!.uni,
                                      ParamType.Document,
                                    ),
                                  }.withoutNulls,
                                  extra: <String, dynamic>{
                                    'college': gridViewCollegesRecord,
                                    'uni': widget!.uni,
                                  },
                                );
                              },
                              child: Container(
                                width: 60.0,
                                height: 22.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent4,
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 4.0,
                                      color: FlutterFlowTheme.of(context)
                                          .alternate,
                                      offset: Offset(
                                        4.0,
                                        4.0,
                                      ),
                                    )
                                  ],
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(20.0),
                                    bottomRight: Radius.circular(20.0),
                                    topLeft: Radius.circular(20.0),
                                    topRight: Radius.circular(20.0),
                                  ),
                                  border: Border.all(
                                    color: FlutterFlowTheme.of(context).accent4,
                                  ),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Text(
                                        gridViewCollegesRecord.collegeName,
                                        textAlign: TextAlign.center,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: '29LTAzer_masarFont',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .logoColor2,
                                              fontSize: 30.0,
                                              letterSpacing: 0.0,
                                              useGoogleFonts: false,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
