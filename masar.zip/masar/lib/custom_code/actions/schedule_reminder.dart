// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:awesome_notifications/awesome_notifications.dart';

Future<int?> scheduleReminder(
  String reminderTitle,
  String reminderMessage,
  DateTime reminderDateTime,
  bool isReminderEnabled,
) async {
  try {
    AwesomeNotifications().initialize(
      null,
      [
        NotificationChannel(
          channelKey: 'reminder_channel',
          channelName: 'Reminder Notifications',
          channelDescription: 'Notifications for reminders',
          importance: NotificationImportance.High,
          channelShowBadge: true,
          locked: false,
        ),
      ],
    );

    bool isPermissionGranted =
        await AwesomeNotifications().isNotificationAllowed();
    if (!isPermissionGranted) {
      await AwesomeNotifications().requestPermissionToSendNotifications();
    }

    String localTimeZone =
        await AwesomeNotifications().getLocalTimeZoneIdentifier();
    DateTime scheduledTime = reminderDateTime.subtract(Duration(days: 1));

    if (isReminderEnabled) {
      int notificationId = DateTime.now().millisecondsSinceEpoch ~/ 1000;

      await AwesomeNotifications().createNotification(
        content: NotificationContent(
          id: notificationId,
          channelKey: 'reminder_channel',
          title: reminderTitle,
          body: "تذكير $reminderMessage",
        ),
        schedule: NotificationCalendar(
          year: scheduledTime.year,
          month: scheduledTime.month,
          day: scheduledTime.day,
          hour: scheduledTime.hour,
          minute: scheduledTime.minute,
          second: 0,
          timeZone: localTimeZone,
          preciseAlarm: true,
          repeats: false,
        ),
      );

      return notificationId;
    } else {
      return null;
    }
  } catch (e) {
    print("Error scheduling reminder: $e");
    return null;
  }
}
