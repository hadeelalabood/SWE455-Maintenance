// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:googleapis_auth/auth_io.dart';

// Add your function code here!
Future<String> addEventToCalendar1(dynamic jsonEvent) async {
  final serviceAccountCredentials = ServiceAccountCredentials.fromJson({
    "type": "service_account",
    "project_id": "calnderdate",
    "private_key_id": "6a6f99e10cf42d2bcdce045addc671e7e575fe4f",
    "private_key":
        "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDIQw9u7pUCDsDS\nniB/zpVRdBLlliwuR7kha6v9+5iO0ZrrLsVs343YlmFfEvLO+UOi4Rultqqhe8oy\nem//BTBNFuFquhCksdw5oAchPOGKiq2/l6Socl7sYUyd//kSUDmSs39Nv2SgXQG1\nD3BU78tKP97+d9vqrcnWF6X7I0/ZAF7YeNpkFG2a23ObYcm6KJ28tvIXFeaQSxY2\nvaxNE3IWUWG39w+SvlFZSkZuInOR5Yt8hu51mTUloXR8zfASCUVLHy2HDEFmBtKD\nuyy5XA/v/U3xBCm+L+1Kh4XyXuwlaZgUHhXaqcel3YkNkO/qIIthXtRBNhy5GtVK\nBaZd9Xj/AgMBAAECggEAJZHnKFGcJNmttRWzVSblfnV/QhEtUrVj9vAjQS/dTBXo\nsWyB304FZ3e25sZARTIgTUNcE3e0hT0bDuNHdZl8mUnMmmAz1SIFBc6O595rFbm0\npPgHDQ7/3erXG+E00gm481u3a1eXwjoQou41jcm64sAezrCf0mQuNHsVSYszZKtH\nJP2c2lZro8dQV2aUsgOPSee5orvvkd86SsyTww1O+p3Yw+qN7NHNaqb0D4PYX6Xw\nMKtH2QRNNKBSi1rjItJPzXm1GLc5qd5g3+FGk6UXrLKA8vvg5AR+3olGSPID6zA9\nsmdhJ4tj7MfmbOeiEYrAPRXSjuASnyV+nYsqkvIf0QKBgQDnzIclcIMeby2D2ysO\nK6qFYPhQ0/el7p9Fr+5F+4mst15OZ1q78ZWtpsMnUwVn5mFS55WWxC18pQdVFxWu\n0P51j1BIVIFjoVZra9eV7f12R4SsDYoAnahOf6AmV4n/sovApAMJyMhksR4cuZ0X\njQYQU8Z4lktg2biJPxt4N7kFBwKBgQDdK55h7/BhbUnzBpeM7MmmZI1Fk1+AKW5t\n77YhrYalqU5+nOTUkbGuc95JQnfPBw/fvqi/hgaWEKz2aBWbsBLl5GDs2dYWG/jI\nkvYsUKeX+dZ7a9HdAYS/0JXHH+VAID5fTi+WGNLNPwAxyDKUsLSVv+ix2qBpZOjf\nBUbVV+wmSQKBgGsniXItSO/QxWGm94hddz6hTSlQU7NJVCeK5MNFPKezPM1RyggH\n7gGQjbaoEl+tiGAi3mwL1FtCjtkvCr79riP6VEqbhhTgiGqwN8D/e6Qp+5Ltz1Xp\ni9x98zLGVOz3RNOQ/jaPstOZbSoqRAyXDK6Pi7hDAiWLgFsx6Sjx2X4RAoGAH/70\nbcSxaNbPsOnOOOP0lC7NxTf5w+e6gwr/tUWOSh8BLQ3ziND+/HbkvIJyJLAn2r2R\nWgvAnisRaqBKJ/jD8yAj6X/mGdK4HgQsuuJ8LF9HaRmDBc73bmx1jpYNq0Y+37jG\n55b1wB2SIKGOt7YMmfFmb3xqYnTnv4Pa6HhMwIkCgYAjyO49YxJcnFb45uBiGB5x\nC+gX4LXwZTFLPSTi4e6WH5qCbbQex2g9IuiOw3H6tJBArDdJAchSdYXS/Na0YXAU\nvLz/fysu6G685QiFnsD223T1+FJiUJVfPuA96fzqFxIspjyJLs8vqwPDPDy3ppWj\nB0PZx5blQqa/ZXgSZfEi5g==\n-----END PRIVATE KEY-----\n",
    "client_email": "lina-368@calnderdate.iam.gserviceaccount.com",
    "client_id": "104478166087197263155",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url":
        "https://www.googleapis.com/robot/v1/metadata/x509/lina-368%40calnderdate.iam.gserviceaccount.com"
  });

  final authClient = await clientViaServiceAccount(
    serviceAccountCredentials,
    ['https://www.googleapis.com/auth/calendar'],
  );

  final url =
      'https://www.googleapis.com/calendar/v3/calendars/61e1822acf88b72992deb621af573f186ce24796d2f898acfcc0cc32fb7eceef@group.calendar.google.com/events'; // Replace with your calendar ID
  final event = jsonEncode(jsonEvent);

  final response = await authClient.post(
    Uri.parse(url),
    headers: {'Content-Type': 'application/json'},
    body: event,
  );

  authClient.close();

  if (response.statusCode == 200) {
    return 'Event added successfully';
  } else {
    return 'Failed to add event: ${response.body}';
  }
}
