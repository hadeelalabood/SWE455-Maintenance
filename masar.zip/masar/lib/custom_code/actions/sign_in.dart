// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_auth/firebase_auth.dart';

Future signIn(
  BuildContext context,
  String email,
  String password,
) async {
  // Reset the login attempt state before attempting to sign in
  FFAppState().update(() {
    FFAppState().loginAttempt = ''; // Reset state
  });

  try {
    final user = await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: password);
    FFAppState().update(() {
      FFAppState().loginAttempt = 'success';
    });
  } on FirebaseAuthException catch (e) {
    if (e.code == 'invalid-credential') {
      FFAppState().update(() {
        FFAppState().loginAttempt = e.code;
      });
    }
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
