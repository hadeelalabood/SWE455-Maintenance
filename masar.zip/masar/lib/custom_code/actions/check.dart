// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<ChatsStudentMentorRecord?> check(
  List<ChatsStudentMentorRecord>? list,
  DocumentReference otherUser,
  DocumentReference authUser,
) async {
  try {
    // If the list is null, return null
    if (list == null) {
      return null;
    }

    // Iterate through the provided list of chat records
    for (final chat in list) {
      // Extract user IDs from the chat document
      final List<DocumentReference> userIds = chat.userlds;

      // Check if both the authenticated user and the other user are in the chat
      if (userIds.contains(authUser) && userIds.contains(otherUser)) {
        return chat; // Return the chat record
      }
    }

    return null; // No chat found
  } catch (e) {
    print('Error in checking chat existence: $e');
    return null; // Return null in case of an error
  }
}
