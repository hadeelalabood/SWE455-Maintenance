import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCWtoRcKyDfs5e2g1j789n5jM2Df-e1MJM",
            authDomain: "masar-ncua6z.firebaseapp.com",
            projectId: "masar-ncua6z",
            storageBucket: "masar-ncua6z.appspot.com",
            messagingSenderId: "857899462016",
            appId: "1:857899462016:web:9f2a32008a45944078e565"));
  } else {
    await Firebase.initializeApp();
  }
}
