import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatsStudentMentorRecord extends FirestoreRecord {
  ChatsStudentMentorRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userlds" field.
  List<DocumentReference>? _userlds;
  List<DocumentReference> get userlds => _userlds ?? const [];
  bool hasUserlds() => _userlds != null;

  // "lastMessage" field.
  String? _lastMessage;
  String get lastMessage => _lastMessage ?? '';
  bool hasLastMessage() => _lastMessage != null;

  // "userNames" field.
  List<String>? _userNames;
  List<String> get userNames => _userNames ?? const [];
  bool hasUserNames() => _userNames != null;

  // "timeStamp" field.
  DateTime? _timeStamp;
  DateTime? get timeStamp => _timeStamp;
  bool hasTimeStamp() => _timeStamp != null;

  // "lastMessageSeenBy" field.
  List<DocumentReference>? _lastMessageSeenBy;
  List<DocumentReference> get lastMessageSeenBy =>
      _lastMessageSeenBy ?? const [];
  bool hasLastMessageSeenBy() => _lastMessageSeenBy != null;

  void _initializeFields() {
    _userlds = getDataList(snapshotData['userlds']);
    _lastMessage = snapshotData['lastMessage'] as String?;
    _userNames = getDataList(snapshotData['userNames']);
    _timeStamp = snapshotData['timeStamp'] as DateTime?;
    _lastMessageSeenBy = getDataList(snapshotData['lastMessageSeenBy']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chatsStudentMentor');

  static Stream<ChatsStudentMentorRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatsStudentMentorRecord.fromSnapshot(s));

  static Future<ChatsStudentMentorRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => ChatsStudentMentorRecord.fromSnapshot(s));

  static ChatsStudentMentorRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ChatsStudentMentorRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatsStudentMentorRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatsStudentMentorRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatsStudentMentorRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatsStudentMentorRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatsStudentMentorRecordData({
  String? lastMessage,
  DateTime? timeStamp,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'lastMessage': lastMessage,
      'timeStamp': timeStamp,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatsStudentMentorRecordDocumentEquality
    implements Equality<ChatsStudentMentorRecord> {
  const ChatsStudentMentorRecordDocumentEquality();

  @override
  bool equals(ChatsStudentMentorRecord? e1, ChatsStudentMentorRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.userlds, e2?.userlds) &&
        e1?.lastMessage == e2?.lastMessage &&
        listEquality.equals(e1?.userNames, e2?.userNames) &&
        e1?.timeStamp == e2?.timeStamp &&
        listEquality.equals(e1?.lastMessageSeenBy, e2?.lastMessageSeenBy);
  }

  @override
  int hash(ChatsStudentMentorRecord? e) => const ListEquality().hash([
        e?.userlds,
        e?.lastMessage,
        e?.userNames,
        e?.timeStamp,
        e?.lastMessageSeenBy
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatsStudentMentorRecord;
}
