import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MajorsRecord extends FirestoreRecord {
  MajorsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "MajorName" field.
  String? _majorName;
  String get majorName => _majorName ?? '';
  bool hasMajorName() => _majorName != null;

  // "Description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "Duration" field.
  String? _duration;
  String get duration => _duration ?? '';
  bool hasDuration() => _duration != null;

  // "Preconditions" field.
  String? _preconditions;
  String get preconditions => _preconditions ?? '';
  bool hasPreconditions() => _preconditions != null;

  // "isMale" field.
  bool? _isMale;
  bool get isMale => _isMale ?? false;
  bool hasIsMale() => _isMale != null;

  // "isFemale" field.
  bool? _isFemale;
  bool get isFemale => _isFemale ?? false;
  bool hasIsFemale() => _isFemale != null;

  // "mSchool" field.
  String? _mSchool;
  String get mSchool => _mSchool ?? '';
  bool hasMSchool() => _mSchool != null;

  // "fSchool" field.
  String? _fSchool;
  String get fSchool => _fSchool ?? '';
  bool hasFSchool() => _fSchool != null;

  // "mQudrat" field.
  String? _mQudrat;
  String get mQudrat => _mQudrat ?? '';
  bool hasMQudrat() => _mQudrat != null;

  // "fQudrat" field.
  String? _fQudrat;
  String get fQudrat => _fQudrat ?? '';
  bool hasFQudrat() => _fQudrat != null;

  // "mTahsili" field.
  String? _mTahsili;
  String get mTahsili => _mTahsili ?? '';
  bool hasMTahsili() => _mTahsili != null;

  // "fTahsili" field.
  String? _fTahsili;
  String get fTahsili => _fTahsili ?? '';
  bool hasFTahsili() => _fTahsili != null;

  // "mOtherTests" field.
  String? _mOtherTests;
  String get mOtherTests => _mOtherTests ?? '';
  bool hasMOtherTests() => _mOtherTests != null;

  // "fOtherTests" field.
  String? _fOtherTests;
  String get fOtherTests => _fOtherTests ?? '';
  bool hasFOtherTests() => _fOtherTests != null;

  // "mWeightPer" field.
  String? _mWeightPer;
  String get mWeightPer => _mWeightPer ?? '';
  bool hasMWeightPer() => _mWeightPer != null;

  // "fWeightPer" field.
  String? _fWeightPer;
  String get fWeightPer => _fWeightPer ?? '';
  bool hasFWeightPer() => _fWeightPer != null;

  // "studentPlan" field.
  String? _studentPlan;
  String get studentPlan => _studentPlan ?? '';
  bool hasStudentPlan() => _studentPlan != null;

  // "College" field.
  DocumentReference? _college;
  DocumentReference? get college => _college;
  bool hasCollege() => _college != null;

  void _initializeFields() {
    _majorName = snapshotData['MajorName'] as String?;
    _description = snapshotData['Description'] as String?;
    _duration = snapshotData['Duration'] as String?;
    _preconditions = snapshotData['Preconditions'] as String?;
    _isMale = snapshotData['isMale'] as bool?;
    _isFemale = snapshotData['isFemale'] as bool?;
    _mSchool = snapshotData['mSchool'] as String?;
    _fSchool = snapshotData['fSchool'] as String?;
    _mQudrat = snapshotData['mQudrat'] as String?;
    _fQudrat = snapshotData['fQudrat'] as String?;
    _mTahsili = snapshotData['mTahsili'] as String?;
    _fTahsili = snapshotData['fTahsili'] as String?;
    _mOtherTests = snapshotData['mOtherTests'] as String?;
    _fOtherTests = snapshotData['fOtherTests'] as String?;
    _mWeightPer = snapshotData['mWeightPer'] as String?;
    _fWeightPer = snapshotData['fWeightPer'] as String?;
    _studentPlan = snapshotData['studentPlan'] as String?;
    _college = snapshotData['College'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Majors');

  static Stream<MajorsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MajorsRecord.fromSnapshot(s));

  static Future<MajorsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MajorsRecord.fromSnapshot(s));

  static MajorsRecord fromSnapshot(DocumentSnapshot snapshot) => MajorsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MajorsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MajorsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MajorsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MajorsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMajorsRecordData({
  String? majorName,
  String? description,
  String? duration,
  String? preconditions,
  bool? isMale,
  bool? isFemale,
  String? mSchool,
  String? fSchool,
  String? mQudrat,
  String? fQudrat,
  String? mTahsili,
  String? fTahsili,
  String? mOtherTests,
  String? fOtherTests,
  String? mWeightPer,
  String? fWeightPer,
  String? studentPlan,
  DocumentReference? college,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'MajorName': majorName,
      'Description': description,
      'Duration': duration,
      'Preconditions': preconditions,
      'isMale': isMale,
      'isFemale': isFemale,
      'mSchool': mSchool,
      'fSchool': fSchool,
      'mQudrat': mQudrat,
      'fQudrat': fQudrat,
      'mTahsili': mTahsili,
      'fTahsili': fTahsili,
      'mOtherTests': mOtherTests,
      'fOtherTests': fOtherTests,
      'mWeightPer': mWeightPer,
      'fWeightPer': fWeightPer,
      'studentPlan': studentPlan,
      'College': college,
    }.withoutNulls,
  );

  return firestoreData;
}

class MajorsRecordDocumentEquality implements Equality<MajorsRecord> {
  const MajorsRecordDocumentEquality();

  @override
  bool equals(MajorsRecord? e1, MajorsRecord? e2) {
    return e1?.majorName == e2?.majorName &&
        e1?.description == e2?.description &&
        e1?.duration == e2?.duration &&
        e1?.preconditions == e2?.preconditions &&
        e1?.isMale == e2?.isMale &&
        e1?.isFemale == e2?.isFemale &&
        e1?.mSchool == e2?.mSchool &&
        e1?.fSchool == e2?.fSchool &&
        e1?.mQudrat == e2?.mQudrat &&
        e1?.fQudrat == e2?.fQudrat &&
        e1?.mTahsili == e2?.mTahsili &&
        e1?.fTahsili == e2?.fTahsili &&
        e1?.mOtherTests == e2?.mOtherTests &&
        e1?.fOtherTests == e2?.fOtherTests &&
        e1?.mWeightPer == e2?.mWeightPer &&
        e1?.fWeightPer == e2?.fWeightPer &&
        e1?.studentPlan == e2?.studentPlan &&
        e1?.college == e2?.college;
  }

  @override
  int hash(MajorsRecord? e) => const ListEquality().hash([
        e?.majorName,
        e?.description,
        e?.duration,
        e?.preconditions,
        e?.isMale,
        e?.isFemale,
        e?.mSchool,
        e?.fSchool,
        e?.mQudrat,
        e?.fQudrat,
        e?.mTahsili,
        e?.fTahsili,
        e?.mOtherTests,
        e?.fOtherTests,
        e?.mWeightPer,
        e?.fWeightPer,
        e?.studentPlan,
        e?.college
      ]);

  @override
  bool isValidKey(Object? o) => o is MajorsRecord;
}
