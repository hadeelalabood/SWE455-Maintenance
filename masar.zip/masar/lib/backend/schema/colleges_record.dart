import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CollegesRecord extends FirestoreRecord {
  CollegesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "CollegeName" field.
  String? _collegeName;
  String get collegeName => _collegeName ?? '';
  bool hasCollegeName() => _collegeName != null;

  // "uniname" field.
  DocumentReference? _uniname;
  DocumentReference? get uniname => _uniname;
  bool hasUniname() => _uniname != null;

  void _initializeFields() {
    _collegeName = snapshotData['CollegeName'] as String?;
    _uniname = snapshotData['uniname'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('colleges');

  static Stream<CollegesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CollegesRecord.fromSnapshot(s));

  static Future<CollegesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CollegesRecord.fromSnapshot(s));

  static CollegesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CollegesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CollegesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CollegesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CollegesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CollegesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCollegesRecordData({
  String? collegeName,
  DocumentReference? uniname,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'CollegeName': collegeName,
      'uniname': uniname,
    }.withoutNulls,
  );

  return firestoreData;
}

class CollegesRecordDocumentEquality implements Equality<CollegesRecord> {
  const CollegesRecordDocumentEquality();

  @override
  bool equals(CollegesRecord? e1, CollegesRecord? e2) {
    return e1?.collegeName == e2?.collegeName && e1?.uniname == e2?.uniname;
  }

  @override
  int hash(CollegesRecord? e) =>
      const ListEquality().hash([e?.collegeName, e?.uniname]);

  @override
  bool isValidKey(Object? o) => o is CollegesRecord;
}
