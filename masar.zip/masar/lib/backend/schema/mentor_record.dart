import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MentorRecord extends FirestoreRecord {
  MentorRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Mentor" field.
  DocumentReference? _mentor;
  DocumentReference? get mentor => _mentor;
  bool hasMentor() => _mentor != null;

  // "Major" field.
  String? _major;
  String get major => _major ?? '';
  bool hasMajor() => _major != null;

  // "UniversityName" field.
  String? _universityName;
  String get universityName => _universityName ?? '';
  bool hasUniversityName() => _universityName != null;

  // "University" field.
  DocumentReference? _university;
  DocumentReference? get university => _university;
  bool hasUniversity() => _university != null;

  // "gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "Name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "firstName" field.
  String? _firstName;
  String get firstName => _firstName ?? '';
  bool hasFirstName() => _firstName != null;

  // "lastName" field.
  String? _lastName;
  String get lastName => _lastName ?? '';
  bool hasLastName() => _lastName != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "MentorprofilePicture" field.
  String? _mentorprofilePicture;
  String get mentorprofilePicture => _mentorprofilePicture ?? '';
  bool hasMentorprofilePicture() => _mentorprofilePicture != null;

  // "mentorCertificate" field.
  String? _mentorCertificate;
  String get mentorCertificate => _mentorCertificate ?? '';
  bool hasMentorCertificate() => _mentorCertificate != null;

  void _initializeFields() {
    _mentor = snapshotData['Mentor'] as DocumentReference?;
    _major = snapshotData['Major'] as String?;
    _universityName = snapshotData['UniversityName'] as String?;
    _university = snapshotData['University'] as DocumentReference?;
    _gender = snapshotData['gender'] as String?;
    _name = snapshotData['Name'] as String?;
    _firstName = snapshotData['firstName'] as String?;
    _lastName = snapshotData['lastName'] as String?;
    _status = snapshotData['status'] as String?;
    _mentorprofilePicture = snapshotData['MentorprofilePicture'] as String?;
    _mentorCertificate = snapshotData['mentorCertificate'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Mentor');

  static Stream<MentorRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MentorRecord.fromSnapshot(s));

  static Future<MentorRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MentorRecord.fromSnapshot(s));

  static MentorRecord fromSnapshot(DocumentSnapshot snapshot) => MentorRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MentorRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MentorRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MentorRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MentorRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMentorRecordData({
  DocumentReference? mentor,
  String? major,
  String? universityName,
  DocumentReference? university,
  String? gender,
  String? name,
  String? firstName,
  String? lastName,
  String? status,
  String? mentorprofilePicture,
  String? mentorCertificate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Mentor': mentor,
      'Major': major,
      'UniversityName': universityName,
      'University': university,
      'gender': gender,
      'Name': name,
      'firstName': firstName,
      'lastName': lastName,
      'status': status,
      'MentorprofilePicture': mentorprofilePicture,
      'mentorCertificate': mentorCertificate,
    }.withoutNulls,
  );

  return firestoreData;
}

class MentorRecordDocumentEquality implements Equality<MentorRecord> {
  const MentorRecordDocumentEquality();

  @override
  bool equals(MentorRecord? e1, MentorRecord? e2) {
    return e1?.mentor == e2?.mentor &&
        e1?.major == e2?.major &&
        e1?.universityName == e2?.universityName &&
        e1?.university == e2?.university &&
        e1?.gender == e2?.gender &&
        e1?.name == e2?.name &&
        e1?.firstName == e2?.firstName &&
        e1?.lastName == e2?.lastName &&
        e1?.status == e2?.status &&
        e1?.mentorprofilePicture == e2?.mentorprofilePicture &&
        e1?.mentorCertificate == e2?.mentorCertificate;
  }

  @override
  int hash(MentorRecord? e) => const ListEquality().hash([
        e?.mentor,
        e?.major,
        e?.universityName,
        e?.university,
        e?.gender,
        e?.name,
        e?.firstName,
        e?.lastName,
        e?.status,
        e?.mentorprofilePicture,
        e?.mentorCertificate
      ]);

  @override
  bool isValidKey(Object? o) => o is MentorRecord;
}
