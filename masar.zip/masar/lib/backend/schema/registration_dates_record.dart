import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegistrationDatesRecord extends FirestoreRecord {
  RegistrationDatesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "UniversityName" field.
  String? _universityName;
  String get universityName => _universityName ?? '';
  bool hasUniversityName() => _universityName != null;

  // "University" field.
  DocumentReference? _university;
  DocumentReference? get university => _university;
  bool hasUniversity() => _university != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "startTime" field.
  DateTime? _startTime;
  DateTime? get startTime => _startTime;
  bool hasStartTime() => _startTime != null;

  // "endTime" field.
  DateTime? _endTime;
  DateTime? get endTime => _endTime;
  bool hasEndTime() => _endTime != null;

  void _initializeFields() {
    _universityName = snapshotData['UniversityName'] as String?;
    _university = snapshotData['University'] as DocumentReference?;
    _description = snapshotData['description'] as String?;
    _startTime = snapshotData['startTime'] as DateTime?;
    _endTime = snapshotData['endTime'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('registrationDates');

  static Stream<RegistrationDatesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegistrationDatesRecord.fromSnapshot(s));

  static Future<RegistrationDatesRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => RegistrationDatesRecord.fromSnapshot(s));

  static RegistrationDatesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegistrationDatesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegistrationDatesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegistrationDatesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegistrationDatesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegistrationDatesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegistrationDatesRecordData({
  String? universityName,
  DocumentReference? university,
  String? description,
  DateTime? startTime,
  DateTime? endTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'UniversityName': universityName,
      'University': university,
      'description': description,
      'startTime': startTime,
      'endTime': endTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegistrationDatesRecordDocumentEquality
    implements Equality<RegistrationDatesRecord> {
  const RegistrationDatesRecordDocumentEquality();

  @override
  bool equals(RegistrationDatesRecord? e1, RegistrationDatesRecord? e2) {
    return e1?.universityName == e2?.universityName &&
        e1?.university == e2?.university &&
        e1?.description == e2?.description &&
        e1?.startTime == e2?.startTime &&
        e1?.endTime == e2?.endTime;
  }

  @override
  int hash(RegistrationDatesRecord? e) => const ListEquality().hash([
        e?.universityName,
        e?.university,
        e?.description,
        e?.startTime,
        e?.endTime
      ]);

  @override
  bool isValidKey(Object? o) => o is RegistrationDatesRecord;
}
