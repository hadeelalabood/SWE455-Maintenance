import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatMessagesStudentMentorRecord extends FirestoreRecord {
  ChatMessagesStudentMentorRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "timeStamp" field.
  DateTime? _timeStamp;
  DateTime? get timeStamp => _timeStamp;
  bool hasTimeStamp() => _timeStamp != null;

  // "uidOfSender" field.
  DocumentReference? _uidOfSender;
  DocumentReference? get uidOfSender => _uidOfSender;
  bool hasUidOfSender() => _uidOfSender != null;

  // "nameOfSender" field.
  String? _nameOfSender;
  String get nameOfSender => _nameOfSender ?? '';
  bool hasNameOfSender() => _nameOfSender != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _message = snapshotData['message'] as String?;
    _timeStamp = snapshotData['timeStamp'] as DateTime?;
    _uidOfSender = snapshotData['uidOfSender'] as DocumentReference?;
    _nameOfSender = snapshotData['nameOfSender'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('chatMessagesStudentMentor')
          : FirebaseFirestore.instance
              .collectionGroup('chatMessagesStudentMentor');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('chatMessagesStudentMentor').doc(id);

  static Stream<ChatMessagesStudentMentorRecord> getDocument(
          DocumentReference ref) =>
      ref
          .snapshots()
          .map((s) => ChatMessagesStudentMentorRecord.fromSnapshot(s));

  static Future<ChatMessagesStudentMentorRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => ChatMessagesStudentMentorRecord.fromSnapshot(s));

  static ChatMessagesStudentMentorRecord fromSnapshot(
          DocumentSnapshot snapshot) =>
      ChatMessagesStudentMentorRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatMessagesStudentMentorRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatMessagesStudentMentorRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatMessagesStudentMentorRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatMessagesStudentMentorRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatMessagesStudentMentorRecordData({
  String? message,
  DateTime? timeStamp,
  DocumentReference? uidOfSender,
  String? nameOfSender,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'message': message,
      'timeStamp': timeStamp,
      'uidOfSender': uidOfSender,
      'nameOfSender': nameOfSender,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatMessagesStudentMentorRecordDocumentEquality
    implements Equality<ChatMessagesStudentMentorRecord> {
  const ChatMessagesStudentMentorRecordDocumentEquality();

  @override
  bool equals(ChatMessagesStudentMentorRecord? e1,
      ChatMessagesStudentMentorRecord? e2) {
    return e1?.message == e2?.message &&
        e1?.timeStamp == e2?.timeStamp &&
        e1?.uidOfSender == e2?.uidOfSender &&
        e1?.nameOfSender == e2?.nameOfSender;
  }

  @override
  int hash(ChatMessagesStudentMentorRecord? e) => const ListEquality()
      .hash([e?.message, e?.timeStamp, e?.uidOfSender, e?.nameOfSender]);

  @override
  bool isValidKey(Object? o) => o is ChatMessagesStudentMentorRecord;
}
