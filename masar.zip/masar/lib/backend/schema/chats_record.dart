import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatsRecord extends FirestoreRecord {
  ChatsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "last_message" field.
  String? _lastMessage;
  String get lastMessage => _lastMessage ?? '';
  bool hasLastMessage() => _lastMessage != null;

  // "last_mes_time" field.
  DateTime? _lastMesTime;
  DateTime? get lastMesTime => _lastMesTime;
  bool hasLastMesTime() => _lastMesTime != null;

  // "users" field.
  List<DocumentReference>? _users;
  List<DocumentReference> get users => _users ?? const [];
  bool hasUsers() => _users != null;

  // "user_stu" field.
  DocumentReference? _userStu;
  DocumentReference? get userStu => _userStu;
  bool hasUserStu() => _userStu != null;

  // "user_men" field.
  DocumentReference? _userMen;
  DocumentReference? get userMen => _userMen;
  bool hasUserMen() => _userMen != null;

  // "UserNames" field.
  List<String>? _userNames;
  List<String> get userNames => _userNames ?? const [];
  bool hasUserNames() => _userNames != null;

  void _initializeFields() {
    _lastMessage = snapshotData['last_message'] as String?;
    _lastMesTime = snapshotData['last_mes_time'] as DateTime?;
    _users = getDataList(snapshotData['users']);
    _userStu = snapshotData['user_stu'] as DocumentReference?;
    _userMen = snapshotData['user_men'] as DocumentReference?;
    _userNames = getDataList(snapshotData['UserNames']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chats');

  static Stream<ChatsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatsRecord.fromSnapshot(s));

  static Future<ChatsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatsRecord.fromSnapshot(s));

  static ChatsRecord fromSnapshot(DocumentSnapshot snapshot) => ChatsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatsRecordData({
  String? lastMessage,
  DateTime? lastMesTime,
  DocumentReference? userStu,
  DocumentReference? userMen,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'last_message': lastMessage,
      'last_mes_time': lastMesTime,
      'user_stu': userStu,
      'user_men': userMen,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatsRecordDocumentEquality implements Equality<ChatsRecord> {
  const ChatsRecordDocumentEquality();

  @override
  bool equals(ChatsRecord? e1, ChatsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.lastMessage == e2?.lastMessage &&
        e1?.lastMesTime == e2?.lastMesTime &&
        listEquality.equals(e1?.users, e2?.users) &&
        e1?.userStu == e2?.userStu &&
        e1?.userMen == e2?.userMen &&
        listEquality.equals(e1?.userNames, e2?.userNames);
  }

  @override
  int hash(ChatsRecord? e) => const ListEquality().hash([
        e?.lastMessage,
        e?.lastMesTime,
        e?.users,
        e?.userStu,
        e?.userMen,
        e?.userNames
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatsRecord;
}
