import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UniversityRecord extends FirestoreRecord {
  UniversityRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "UniName" field.
  String? _uniName;
  String get uniName => _uniName ?? '';
  bool hasUniName() => _uniName != null;

  // "UniEmail" field.
  String? _uniEmail;
  String get uniEmail => _uniEmail ?? '';
  bool hasUniEmail() => _uniEmail != null;

  // "UniPassword" field.
  String? _uniPassword;
  String get uniPassword => _uniPassword ?? '';
  bool hasUniPassword() => _uniPassword != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "profilePicture" field.
  String? _profilePicture;
  String get profilePicture => _profilePicture ?? '';
  bool hasProfilePicture() => _profilePicture != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  bool hasWebsite() => _website != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "display_nsme" field.
  String? _displayNsme;
  String get displayNsme => _displayNsme ?? '';
  bool hasDisplayNsme() => _displayNsme != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "University" field.
  DocumentReference? _university;
  DocumentReference? get university => _university;
  bool hasUniversity() => _university != null;

  // "XAccount" field.
  String? _xAccount;
  String get xAccount => _xAccount ?? '';
  bool hasXAccount() => _xAccount != null;

  // "contactEmail" field.
  String? _contactEmail;
  String get contactEmail => _contactEmail ?? '';
  bool hasContactEmail() => _contactEmail != null;

  // "UniMentors" field.
  List<DocumentReference>? _uniMentors;
  List<DocumentReference> get uniMentors => _uniMentors ?? const [];
  bool hasUniMentors() => _uniMentors != null;

  // "Status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  void _initializeFields() {
    _uniName = snapshotData['UniName'] as String?;
    _uniEmail = snapshotData['UniEmail'] as String?;
    _uniPassword = snapshotData['UniPassword'] as String?;
    _description = snapshotData['description'] as String?;
    _profilePicture = snapshotData['profilePicture'] as String?;
    _website = snapshotData['website'] as String?;
    _uid = snapshotData['uid'] as String?;
    _displayNsme = snapshotData['display_nsme'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _university = snapshotData['University'] as DocumentReference?;
    _xAccount = snapshotData['XAccount'] as String?;
    _contactEmail = snapshotData['contactEmail'] as String?;
    _uniMentors = getDataList(snapshotData['UniMentors']);
    _status = snapshotData['Status'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('University');

  static Stream<UniversityRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UniversityRecord.fromSnapshot(s));

  static Future<UniversityRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UniversityRecord.fromSnapshot(s));

  static UniversityRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UniversityRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UniversityRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UniversityRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UniversityRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UniversityRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUniversityRecordData({
  String? uniName,
  String? uniEmail,
  String? uniPassword,
  String? description,
  String? profilePicture,
  String? website,
  String? uid,
  String? displayNsme,
  DateTime? createdTime,
  DocumentReference? university,
  String? xAccount,
  String? contactEmail,
  String? status,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'UniName': uniName,
      'UniEmail': uniEmail,
      'UniPassword': uniPassword,
      'description': description,
      'profilePicture': profilePicture,
      'website': website,
      'uid': uid,
      'display_nsme': displayNsme,
      'created_time': createdTime,
      'University': university,
      'XAccount': xAccount,
      'contactEmail': contactEmail,
      'Status': status,
    }.withoutNulls,
  );

  return firestoreData;
}

class UniversityRecordDocumentEquality implements Equality<UniversityRecord> {
  const UniversityRecordDocumentEquality();

  @override
  bool equals(UniversityRecord? e1, UniversityRecord? e2) {
    const listEquality = ListEquality();
    return e1?.uniName == e2?.uniName &&
        e1?.uniEmail == e2?.uniEmail &&
        e1?.uniPassword == e2?.uniPassword &&
        e1?.description == e2?.description &&
        e1?.profilePicture == e2?.profilePicture &&
        e1?.website == e2?.website &&
        e1?.uid == e2?.uid &&
        e1?.displayNsme == e2?.displayNsme &&
        e1?.createdTime == e2?.createdTime &&
        e1?.university == e2?.university &&
        e1?.xAccount == e2?.xAccount &&
        e1?.contactEmail == e2?.contactEmail &&
        listEquality.equals(e1?.uniMentors, e2?.uniMentors) &&
        e1?.status == e2?.status;
  }

  @override
  int hash(UniversityRecord? e) => const ListEquality().hash([
        e?.uniName,
        e?.uniEmail,
        e?.uniPassword,
        e?.description,
        e?.profilePicture,
        e?.website,
        e?.uid,
        e?.displayNsme,
        e?.createdTime,
        e?.university,
        e?.xAccount,
        e?.contactEmail,
        e?.uniMentors,
        e?.status
      ]);

  @override
  bool isValidKey(Object? o) => o is UniversityRecord;
}
