import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    safeSetState(() => _loading = true);
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        if (mounted) {
          context.pushNamed(
            initialPageName,
            pathParameters: parameterData.pathParameters,
            extra: parameterData.extra,
          );
        } else {
          appNavigatorKey.currentContext?.pushNamed(
            initialPageName,
            pathParameters: parameterData.pathParameters,
            extra: parameterData.extra,
          );
        }
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      safeSetState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      handleOpenedPushNotification();
    });
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: FlutterFlowTheme.of(context).primaryBackground,
          child: Image.asset(
            'assets/images/Animation_-_1725799732461.gif',
            fit: BoxFit.contain,
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'HomePageStudent': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'CreateStudent': ParameterData.none(),
  'Onboarding01': ParameterData.none(),
  'ForgotPassword': ParameterData.none(),
  'ForgotPasswordSent': ParameterData.none(),
  'university_HomePage': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'verifyemail': ParameterData.none(),
  'approveMentor': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'registrationDates': (data) async => ParameterData(
        allParams: {
          'accessToken': getParameter<String>(data, 'accessToken'),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'add_major_form': (data) async => ParameterData(
        allParams: {
          'college': await getDocumentParameter<CollegesRecord>(
              data, 'college', CollegesRecord.fromSnapshot),
        },
      ),
  'college_page': (data) async => ParameterData(
        allParams: {
          'college': await getDocumentParameter<CollegesRecord>(
              data, 'college', CollegesRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'view_major_details': (data) async => ParameterData(
        allParams: {
          'majorDoc': await getDocumentParameter<MajorsRecord>(
              data, 'majorDoc', MajorsRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
          'collage': await getDocumentParameter<CollegesRecord>(
              data, 'collage', CollegesRecord.fromSnapshot),
        },
      ),
  'CreateAccountBoth': ParameterData.none(),
  'HomePageAdmin': ParameterData.none(),
  'universityProfile': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'createUniversity': ParameterData.none(),
  'adminProfile': ParameterData.none(),
  'studenProfile': (data) async => ParameterData(
        allParams: {
          'stu': await getDocumentParameter<StudentRecord>(
              data, 'stu', StudentRecord.fromSnapshot),
        },
      ),
  'LoginStudentCopy': ParameterData.none(),
  'HomePageMentor': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
        },
      ),
  'addEvents': ParameterData.none(),
  'CreateMentor': ParameterData.none(),
  'testsearch': ParameterData.none(),
  'profi': ParameterData.none(),
  'studenProfileCopy': (data) async => ParameterData(
        allParams: {
          'stu': await getDocumentParameter<StudentRecord>(
              data, 'stu', StudentRecord.fromSnapshot),
          'usee': await getDocumentParameter<UsersRecord>(
              data, 'usee', UsersRecord.fromSnapshot),
        },
      ),
  'registrationDatesCopy': (data) async => ParameterData(
        allParams: {
          'accessToken': getParameter<String>(data, 'accessToken'),
        },
      ),
  'mentorsList': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'universitiesList': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'forgetpasswordTimer': ParameterData.none(),
  'registrationDatesUniversity': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'registrationDatesStudent1': ParameterData.none(),
  'createUniversityCopy': ParameterData.none(),
  'testlogin': ParameterData.none(),
  'mentorProfile2': (data) async => ParameterData(
        allParams: {
          'mentors': await getDocumentParameter<MentorRecord>(
              data, 'mentors', MentorRecord.fromSnapshot),
        },
      ),
  'studentUniversityView': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'universityProfileCopyCopy': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'verifyemailLogin': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'mentorProfile2Copy': (data) async => ParameterData(
        allParams: {
          'mentors': await getDocumentParameter<MentorRecord>(
              data, 'mentors', MentorRecord.fromSnapshot),
        },
      ),
  'pendding_page_for_mentor': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
        },
      ),
  'mentorDetailss': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
        },
      ),
  'viewMentors': (data) async => ParameterData(
        allParams: {
          'accepted': getParameter<String>(data, 'accepted'),
        },
      ),
  'ViewlistUni': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'AdminUniversityView': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'pendding_page_for_Uni': (data) async => ParameterData(
        allParams: {
          'uniw': await getDocumentParameter<UniversityRecord>(
              data, 'uniw', UniversityRecord.fromSnapshot),
        },
      ),
  'createUniversityCopy2': ParameterData.none(),
  'MentorsListUniversty': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'UniversityM': (data) async => ParameterData(
        allParams: {
          'mento': await getDocumentParameter<MentorRecord>(
              data, 'mento', MentorRecord.fromSnapshot),
        },
      ),
  'mentorUniversityView': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
        },
      ),
  'uni_view_mentorDetails': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
          'univ': await getDocumentParameter<UniversityRecord>(
              data, 'univ', UniversityRecord.fromSnapshot),
        },
      ),
  'uni_view_mentorDetailsCopy': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
        },
      ),
  'EditMajor': (data) async => ParameterData(
        allParams: {
          'majorDoc': await getDocumentParameter<MajorsRecord>(
              data, 'majorDoc', MajorsRecord.fromSnapshot),
        },
      ),
  'EditMajorCopy': (data) async => ParameterData(
        allParams: {
          'majorDoc': await getDocumentParameter<MajorsRecord>(
              data, 'majorDoc', MajorsRecord.fromSnapshot),
        },
      ),
  'EditCollege': (data) async => ParameterData(
        allParams: {
          'collegee': await getDocumentParameter<CollegesRecord>(
              data, 'collegee', CollegesRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'MentorViewMajor': (data) async => ParameterData(
        allParams: {
          'college': await getDocumentParameter<CollegesRecord>(
              data, 'college', CollegesRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'AdminUniversityViewCopy': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'approveUniversity': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'AdminUniversityViewApproved': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'StudentViewMajor': (data) async => ParameterData(
        allParams: {
          'college': await getDocumentParameter<CollegesRecord>(
              data, 'college', CollegesRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'mentorsListCopy': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'edit_major_form': (data) async => ParameterData(
        allParams: {
          'college': await getDocumentParameter<CollegesRecord>(
              data, 'college', CollegesRecord.fromSnapshot),
          'major': await getDocumentParameter<MajorsRecord>(
              data, 'major', MajorsRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'EditCollegeCopy': (data) async => ParameterData(
        allParams: {
          'collegee': await getDocumentParameter<CollegesRecord>(
              data, 'collegee', CollegesRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'universityProfileCopyCopyCopy': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'EditMajor2': (data) async => ParameterData(
        allParams: {
          'college': await getDocumentParameter<CollegesRecord>(
              data, 'college', CollegesRecord.fromSnapshot),
        },
      ),
  'StudentViewCollage': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'MentorViewCollage': (data) async => ParameterData(
        allParams: {
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
        },
      ),
  'studentViewMajorDetails': (data) async => ParameterData(
        allParams: {
          'majorDoc': await getDocumentParameter<MajorsRecord>(
              data, 'majorDoc', MajorsRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
          'collage': await getDocumentParameter<CollegesRecord>(
              data, 'collage', CollegesRecord.fromSnapshot),
        },
      ),
  'Disapp_page_for_Uni': (data) async => ParameterData(
        allParams: {
          'uniw': await getDocumentParameter<UniversityRecord>(
              data, 'uniw', UniversityRecord.fromSnapshot),
        },
      ),
  'chat_ai_Screen': ParameterData.none(),
  'chat_ai_Screen_1': ParameterData.none(),
  'chat_M_Screen': (data) async => ParameterData(
        allParams: {
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
          'recChat': getParameter<DocumentReference>(data, 'recChat'),
        },
      ),
  'AllChats': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
          'mentor': await getDocumentParameter<MentorRecord>(
              data, 'mentor', MentorRecord.fromSnapshot),
        },
      ),
  'ChatPage': (data) async => ParameterData(
        allParams: {
          'reciveChat': getParameter<DocumentReference>(data, 'reciveChat'),
        },
      ),
  'mentorsListChat': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'HomePageStudentCopyCopy': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
  'chat_ai_ScreenCopy': ParameterData.none(),
  'MentorViewMajorDetails': (data) async => ParameterData(
        allParams: {
          'majorDoc': await getDocumentParameter<MajorsRecord>(
              data, 'majorDoc', MajorsRecord.fromSnapshot),
          'uni': await getDocumentParameter<UniversityRecord>(
              data, 'uni', UniversityRecord.fromSnapshot),
          'collage': await getDocumentParameter<CollegesRecord>(
              data, 'collage', CollegesRecord.fromSnapshot),
        },
      ),
  'calculator': (data) async => ParameterData(
        allParams: {
          'student': await getDocumentParameter<StudentRecord>(
              data, 'student', StudentRecord.fromSnapshot),
        },
      ),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
