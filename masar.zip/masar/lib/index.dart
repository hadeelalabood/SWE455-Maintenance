// Export pages
export '/student/home_page_student/home_page_student_widget.dart'
    show HomePageStudentWidget;
export '/account_profile_creation/create_student/create_student_widget.dart'
    show CreateStudentWidget;
export '/account_profile_creation/onboarding01/onboarding01_widget.dart'
    show Onboarding01Widget;
export '/account_profile_creation/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/account_profile_creation/forgot_password_sent/forgot_password_sent_widget.dart'
    show ForgotPasswordSentWidget;
export '/university/university_home_page/university_home_page_widget.dart'
    show UniversityHomePageWidget;
export '/account_profile_creation/verifyemail/verifyemail_widget.dart'
    show VerifyemailWidget;
export '/university/approve_mentor/approve_mentor_widget.dart'
    show ApproveMentorWidget;
export '/university/registration_dates/registration_dates_widget.dart'
    show RegistrationDatesWidget;
export '/university/add_major_form/add_major_form_widget.dart'
    show AddMajorFormWidget;
export '/university/college_page/college_page_widget.dart'
    show CollegePageWidget;
export '/university/view_major_details/view_major_details_widget.dart'
    show ViewMajorDetailsWidget;
export '/account_profile_creation/create_account_both/create_account_both_widget.dart'
    show CreateAccountBothWidget;
export '/admin/home_page_admin/home_page_admin_widget.dart'
    show HomePageAdminWidget;
export '/university/university_profile/university_profile_widget.dart'
    show UniversityProfileWidget;
export '/account_profile_creation/create_university/create_university_widget.dart'
    show CreateUniversityWidget;
export '/admin/admin_profile/admin_profile_widget.dart' show AdminProfileWidget;
export '/student/studen_profile/studen_profile_widget.dart'
    show StudenProfileWidget;
export '/account_profile_creation/login_student_copy/login_student_copy_widget.dart'
    show LoginStudentCopyWidget;
export '/mentor/home_page_mentor/home_page_mentor_widget.dart'
    show HomePageMentorWidget;
export '/university/add_events/add_events_widget.dart' show AddEventsWidget;
export '/account_profile_creation/create_mentor/create_mentor_widget.dart'
    show CreateMentorWidget;
export '/testsearch/testsearch_widget.dart' show TestsearchWidget;
export '/profi/profi_widget.dart' show ProfiWidget;
export '/student/studen_profile_copy/studen_profile_copy_widget.dart'
    show StudenProfileCopyWidget;
export '/student/registration_dates_copy/registration_dates_copy_widget.dart'
    show RegistrationDatesCopyWidget;
export '/student/mentors_list/mentors_list_widget.dart' show MentorsListWidget;
export '/student/universities_list/universities_list_widget.dart'
    show UniversitiesListWidget;
export '/account_profile_creation/forgetpassword_timer/forgetpassword_timer_widget.dart'
    show ForgetpasswordTimerWidget;
export '/university/registration_dates_university/registration_dates_university_widget.dart'
    show RegistrationDatesUniversityWidget;
export '/student/registration_dates_student1/registration_dates_student1_widget.dart'
    show RegistrationDatesStudent1Widget;
export '/account_profile_creation/create_university_copy/create_university_copy_widget.dart'
    show CreateUniversityCopyWidget;
export '/testlogin/testlogin_widget.dart' show TestloginWidget;
export '/mentor/mentor_profile2/mentor_profile2_widget.dart'
    show MentorProfile2Widget;
export '/student/student_university_view/student_university_view_widget.dart'
    show StudentUniversityViewWidget;
export '/university/university_profile_copy_copy/university_profile_copy_copy_widget.dart'
    show UniversityProfileCopyCopyWidget;
export '/account_profile_creation/verifyemail_login/verifyemail_login_widget.dart'
    show VerifyemailLoginWidget;
export '/mentor/mentor_profile2_copy/mentor_profile2_copy_widget.dart'
    show MentorProfile2CopyWidget;
export '/mentor/pendding_page_for_mentor/pendding_page_for_mentor_widget.dart'
    show PenddingPageForMentorWidget;
export '/mentor_detailss/mentor_detailss_widget.dart' show MentorDetailssWidget;
export '/university/view_mentors/view_mentors_widget.dart'
    show ViewMentorsWidget;
export '/admin/viewlist_uni/viewlist_uni_widget.dart' show ViewlistUniWidget;
export '/admin/admin_university_view/admin_university_view_widget.dart'
    show AdminUniversityViewWidget;
export '/university/pendding_page_for_uni/pendding_page_for_uni_widget.dart'
    show PenddingPageForUniWidget;
export '/account_profile_creation/create_university_copy2/create_university_copy2_widget.dart'
    show CreateUniversityCopy2Widget;
export '/university/mentors_list_universty/mentors_list_universty_widget.dart'
    show MentorsListUniverstyWidget;
export '/mentor/university_m/university_m_widget.dart' show UniversityMWidget;
export '/mentor/mentor_university_view/mentor_university_view_widget.dart'
    show MentorUniversityViewWidget;
export '/university/uni_view_mentor_details/uni_view_mentor_details_widget.dart'
    show UniViewMentorDetailsWidget;
export '/university/uni_view_mentor_details_copy/uni_view_mentor_details_copy_widget.dart'
    show UniViewMentorDetailsCopyWidget;
export '/university/edit_major/edit_major_widget.dart' show EditMajorWidget;
export '/university/edit_major_copy/edit_major_copy_widget.dart'
    show EditMajorCopyWidget;
export '/university/edit_college/edit_college_widget.dart'
    show EditCollegeWidget;
export '/mentor/mentor_view_major/mentor_view_major_widget.dart'
    show MentorViewMajorWidget;
export '/admin/admin_university_view_copy/admin_university_view_copy_widget.dart'
    show AdminUniversityViewCopyWidget;
export '/admin/approve_university/approve_university_widget.dart'
    show ApproveUniversityWidget;
export '/admin/admin_university_view_approved/admin_university_view_approved_widget.dart'
    show AdminUniversityViewApprovedWidget;
export '/student/student_view_major/student_view_major_widget.dart'
    show StudentViewMajorWidget;
export '/student/mentors_list_copy/mentors_list_copy_widget.dart'
    show MentorsListCopyWidget;
export '/university/edit_major_form/edit_major_form_widget.dart'
    show EditMajorFormWidget;
export '/university/edit_college_copy/edit_college_copy_widget.dart'
    show EditCollegeCopyWidget;
export '/university/university_profile_copy_copy_copy/university_profile_copy_copy_copy_widget.dart'
    show UniversityProfileCopyCopyCopyWidget;
export '/university/edit_major2/edit_major2_widget.dart' show EditMajor2Widget;
export '/student/student_view_collage/student_view_collage_widget.dart'
    show StudentViewCollageWidget;
export '/mentor/mentor_view_collage/mentor_view_collage_widget.dart'
    show MentorViewCollageWidget;
export '/student/student_view_major_details/student_view_major_details_widget.dart'
    show StudentViewMajorDetailsWidget;
export '/university/disapp_page_for_uni/disapp_page_for_uni_widget.dart'
    show DisappPageForUniWidget;
export '/chat/chat_ai_screen/chat_ai_screen_widget.dart'
    show ChatAiScreenWidget;
export '/chat_gbt/chat_ai_screen_1/chat_ai_screen1_widget.dart'
    show ChatAiScreen1Widget;
export '/student/chat_m_screen/chat_m_screen_widget.dart'
    show ChatMScreenWidget;
export '/student/all_chats/all_chats_widget.dart' show AllChatsWidget;
export '/chat_page/chat_page_widget.dart' show ChatPageWidget;
export '/student/mentors_list_chat/mentors_list_chat_widget.dart'
    show MentorsListChatWidget;
export '/student/home_page_student_copy_copy/home_page_student_copy_copy_widget.dart'
    show HomePageStudentCopyCopyWidget;
export '/chat/chat_ai_screen_copy/chat_ai_screen_copy_widget.dart'
    show ChatAiScreenCopyWidget;
export '/mentor/mentor_view_major_details/mentor_view_major_details_widget.dart'
    show MentorViewMajorDetailsWidget;
export '/student/calculator/calculator_widget.dart' show CalculatorWidget;
