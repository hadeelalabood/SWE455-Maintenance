import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

String? processInput(String? input) {
  // Handle null input
  if (input == null) {
    return '';
  }

  int start = 0;
  int end = input.length - 1;

  // Step 1: Trim leading and trailing spaces
  while (start <= end && input[start] == ' ') {
    start++;
  }
  while (end >= start && input[end] == ' ') {
    end--;
  }

  // If the entire string was spaces, return an empty string
  if (start > end) {
    return '';
  }

  // Trimmed string
  String trimmedInput = input.substring(start, end + 1);

  // Step 2: Convert Arabic numerals to English
  Map<String, String> arabicToEnglish = {
    '٠': '0',
    '١': '1',
    '٢': '2',
    '٣': '3',
    '٤': '4',
    '٥': '5',
    '٦': '6',
    '٧': '7',
    '٨': '8',
    '٩': '9',
  };

  String convertedInput = trimmedInput.split('').map((char) {
    return arabicToEnglish[char] ??
        char; // Default to original char if not found
  }).join('');

  // Step 3: Convert 'ه' to 'ة' if it appears at the end of any word
  convertedInput = convertedInput.split(' ').map((word) {
    // If the word ends with 'ه', replace it with 'ة'
    if (word.endsWith('ه')) {
      return word.substring(0, word.length - 1) + 'ة';
    }
    return word; // Otherwise, return the word unchanged
  }).join(' ');

  // Return the final processed input
  return convertedInput;
}

String convertIsoString(
  String iso8601String,
  String format,
) {
  DateTime startDateTime = DateTime.parse(iso8601String);
  String time12hr = DateFormat(format).format(startDateTime);
  return time12hr;
}

DateTime convertToDateTime(String dateString) {
  return DateTime.parse(dateString);
}

DateTime subtractTime(DateTime inputDateTime) {
  return inputDateTime.subtract(Duration(days: 1));
}

dynamic saveChatHistory(
  dynamic chatHistory,
  dynamic newChat,
) {
  // Predefined instruction for OpenAI
  const predefinedInstruction = {
    "role": "system",
    "content": '''
أهلًا وسهلًا! 😊 أنا مساعدك الالي  لأساعدك في الإجابة على أسئلتك حول التخصصات، وأيضًا يمكنني تقديم اختبار خفيف من 10 أسئلة يساعدك في اكتشاف ميولك المهنية بطريقة ممتعة! 🎯 
بس حاب أوضح، اختصاصي يركز على هالموضوعين فقط ولا اقدر اطلع عنها 🧑‍💻✨ 
وش رأيك؟ نبدأ بالاختبار أو عندك استفسار تحب أساعدك فيه؟ 🌟

'''
  };

  // If chatHistory isn't a list, initialize it with the predefined instruction
  if (chatHistory is! List) {
    return [predefinedInstruction, newChat];
  }

  // If chatHistory is empty, add the predefined instruction
  if (chatHistory.isEmpty) {
    chatHistory.add(predefinedInstruction);
  }

  // Append the new chat message to the existing chatHistory
  chatHistory.add(newChat);

  return chatHistory;
}

dynamic convertToJSON(String prompt) {
  // take the prompt and return a JSON with form [{"role": "user", "content": prompt}]
  return json.decode('{"role": "user", "content": "$prompt"}');
}

int percentageToInt(String percentage) {
  return int.parse(percentage.replaceAll('%', ''));
}

bool validateTotal(
  int p1,
  int p2,
  int p3,
) {
  int total = p1 + p2 + p3;
  return total == 100;
}

double? calculateFinalResult(
  double v1,
  double v2,
  double v3,
  int p1,
  int p2,
  int p3,
) {
  // Convert percentages to decimals
  final double percent1Decimal = p1 / 100.0;
  final double percent2Decimal = p2 / 100.0;
  final double percent3Decimal = p3 / 100.0;

  // Calculate the final result
  final double result =
      (v1 * percent1Decimal) + (v2 * percent2Decimal) + (v3 * percent3Decimal);

  return result;
}

bool validateTotal4(
  int p1,
  int p2,
  int p3,
  int p4,
) {
  int total = p1 + p2 + p3 + p4;
  return total == 100;
}

double? calculatepercentage(
  int p1,
  int p2,
  int p3,
  int p4,
  double v1,
  double v2,
  double v3,
  double v4,
) {
  final double percent1Decimal = p1 / 100.0;
  final double percent2Decimal = p2 / 100.0;
  final double percent3Decimal = p3 / 100.0;
  final double percent4Decimal = p4 / 100.0;

  // Calculate the final result
  final double result = (v1 * percent1Decimal) +
      (v2 * percent2Decimal) +
      (v3 * percent3Decimal) +
      (v4 * percent4Decimal);
  return double.parse(result.toStringAsFixed(2));
  //return result;
}

List<String> generateListOfNames(
  String authUserName,
  String otherUserName,
) {
  return [authUserName, otherUserName];
}

List<DocumentReference> generateListOfUsers(
  DocumentReference authUser,
  DocumentReference otherUser,
) {
  return [authUser, otherUser];
}

String getOtherUserName(
  List<String> listOfNames,
  String authUserName,
) {
  return authUserName == listOfNames.first
      ? listOfNames.last
      : listOfNames.first;
}

DocumentReference getOtherUserRef(
  List<DocumentReference> listOfUserRefs,
  DocumentReference authUserRef,
) {
  return authUserRef == listOfUserRefs.first
      ? listOfUserRefs.last
      : listOfUserRefs.first;
}

double valueTodouble(String v) {
  return double.parse(v);
}
