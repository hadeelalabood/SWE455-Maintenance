import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';

import '/auth/base_auth_user_provider.dart';

import '/backend/push_notifications/push_notifications_handler.dart'
    show PushNotificationsHandler;
import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) => appStateNotifier.loggedIn
          ? LoginStudentCopyWidget()
          : Onboarding01Widget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => appStateNotifier.loggedIn
              ? LoginStudentCopyWidget()
              : Onboarding01Widget(),
        ),
        FFRoute(
          name: HomePageStudentWidget.routeName,
          path: HomePageStudentWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => HomePageStudentWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: CreateStudentWidget.routeName,
          path: CreateStudentWidget.routePath,
          builder: (context, params) => CreateStudentWidget(),
        ),
        FFRoute(
          name: Onboarding01Widget.routeName,
          path: Onboarding01Widget.routePath,
          builder: (context, params) => Onboarding01Widget(),
        ),
        FFRoute(
          name: ForgotPasswordWidget.routeName,
          path: ForgotPasswordWidget.routePath,
          builder: (context, params) => ForgotPasswordWidget(),
        ),
        FFRoute(
          name: ForgotPasswordSentWidget.routeName,
          path: ForgotPasswordSentWidget.routePath,
          builder: (context, params) => ForgotPasswordSentWidget(),
        ),
        FFRoute(
          name: UniversityHomePageWidget.routeName,
          path: UniversityHomePageWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => UniversityHomePageWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: VerifyemailWidget.routeName,
          path: VerifyemailWidget.routePath,
          builder: (context, params) => VerifyemailWidget(),
        ),
        FFRoute(
          name: ApproveMentorWidget.routeName,
          path: ApproveMentorWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => ApproveMentorWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: RegistrationDatesWidget.routeName,
          path: RegistrationDatesWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => RegistrationDatesWidget(
            accessToken: params.getParam(
              'accessToken',
              ParamType.String,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: AddMajorFormWidget.routeName,
          path: AddMajorFormWidget.routePath,
          asyncParams: {
            'college': getDoc(['colleges'], CollegesRecord.fromSnapshot),
          },
          builder: (context, params) => AddMajorFormWidget(
            college: params.getParam(
              'college',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: CollegePageWidget.routeName,
          path: CollegePageWidget.routePath,
          asyncParams: {
            'college': getDoc(['colleges'], CollegesRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => CollegePageWidget(
            college: params.getParam(
              'college',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ViewMajorDetailsWidget.routeName,
          path: ViewMajorDetailsWidget.routePath,
          asyncParams: {
            'majorDoc': getDoc(['Majors'], MajorsRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
            'collage': getDoc(['colleges'], CollegesRecord.fromSnapshot),
          },
          builder: (context, params) => ViewMajorDetailsWidget(
            majorDoc: params.getParam(
              'majorDoc',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
            collage: params.getParam(
              'collage',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: CreateAccountBothWidget.routeName,
          path: CreateAccountBothWidget.routePath,
          builder: (context, params) => CreateAccountBothWidget(),
        ),
        FFRoute(
          name: HomePageAdminWidget.routeName,
          path: HomePageAdminWidget.routePath,
          builder: (context, params) => HomePageAdminWidget(),
        ),
        FFRoute(
          name: UniversityProfileWidget.routeName,
          path: UniversityProfileWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => UniversityProfileWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: CreateUniversityWidget.routeName,
          path: CreateUniversityWidget.routePath,
          builder: (context, params) => CreateUniversityWidget(),
        ),
        FFRoute(
          name: AdminProfileWidget.routeName,
          path: AdminProfileWidget.routePath,
          builder: (context, params) => AdminProfileWidget(),
        ),
        FFRoute(
          name: StudenProfileWidget.routeName,
          path: StudenProfileWidget.routePath,
          asyncParams: {
            'stu': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => StudenProfileWidget(
            stu: params.getParam(
              'stu',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: LoginStudentCopyWidget.routeName,
          path: LoginStudentCopyWidget.routePath,
          builder: (context, params) => LoginStudentCopyWidget(),
        ),
        FFRoute(
          name: HomePageMentorWidget.routeName,
          path: HomePageMentorWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => HomePageMentorWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: AddEventsWidget.routeName,
          path: AddEventsWidget.routePath,
          builder: (context, params) => AddEventsWidget(),
        ),
        FFRoute(
          name: CreateMentorWidget.routeName,
          path: CreateMentorWidget.routePath,
          builder: (context, params) => CreateMentorWidget(),
        ),
        FFRoute(
          name: TestsearchWidget.routeName,
          path: TestsearchWidget.routePath,
          builder: (context, params) => TestsearchWidget(),
        ),
        FFRoute(
          name: ProfiWidget.routeName,
          path: ProfiWidget.routePath,
          builder: (context, params) => ProfiWidget(),
        ),
        FFRoute(
          name: StudenProfileCopyWidget.routeName,
          path: StudenProfileCopyWidget.routePath,
          asyncParams: {
            'stu': getDoc(['student'], StudentRecord.fromSnapshot),
            'usee': getDoc(['users'], UsersRecord.fromSnapshot),
          },
          builder: (context, params) => StudenProfileCopyWidget(
            stu: params.getParam(
              'stu',
              ParamType.Document,
            ),
            usee: params.getParam(
              'usee',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: RegistrationDatesCopyWidget.routeName,
          path: RegistrationDatesCopyWidget.routePath,
          builder: (context, params) => RegistrationDatesCopyWidget(
            accessToken: params.getParam(
              'accessToken',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: MentorsListWidget.routeName,
          path: MentorsListWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => MentorsListWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: UniversitiesListWidget.routeName,
          path: UniversitiesListWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => UniversitiesListWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ForgetpasswordTimerWidget.routeName,
          path: ForgetpasswordTimerWidget.routePath,
          builder: (context, params) => ForgetpasswordTimerWidget(),
        ),
        FFRoute(
          name: RegistrationDatesUniversityWidget.routeName,
          path: RegistrationDatesUniversityWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => RegistrationDatesUniversityWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: RegistrationDatesStudent1Widget.routeName,
          path: RegistrationDatesStudent1Widget.routePath,
          builder: (context, params) => RegistrationDatesStudent1Widget(),
        ),
        FFRoute(
          name: CreateUniversityCopyWidget.routeName,
          path: CreateUniversityCopyWidget.routePath,
          builder: (context, params) => CreateUniversityCopyWidget(),
        ),
        FFRoute(
          name: TestloginWidget.routeName,
          path: TestloginWidget.routePath,
          builder: (context, params) => TestloginWidget(),
        ),
        FFRoute(
          name: MentorProfile2Widget.routeName,
          path: MentorProfile2Widget.routePath,
          asyncParams: {
            'mentors': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => MentorProfile2Widget(
            mentors: params.getParam(
              'mentors',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: StudentUniversityViewWidget.routeName,
          path: StudentUniversityViewWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => StudentUniversityViewWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: UniversityProfileCopyCopyWidget.routeName,
          path: UniversityProfileCopyCopyWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => UniversityProfileCopyCopyWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: VerifyemailLoginWidget.routeName,
          path: VerifyemailLoginWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => VerifyemailLoginWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: MentorProfile2CopyWidget.routeName,
          path: MentorProfile2CopyWidget.routePath,
          asyncParams: {
            'mentors': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => MentorProfile2CopyWidget(
            mentors: params.getParam(
              'mentors',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: PenddingPageForMentorWidget.routeName,
          path: PenddingPageForMentorWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => PenddingPageForMentorWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: MentorDetailssWidget.routeName,
          path: MentorDetailssWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => MentorDetailssWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ViewMentorsWidget.routeName,
          path: ViewMentorsWidget.routePath,
          builder: (context, params) => ViewMentorsWidget(
            accepted: params.getParam(
              'accepted',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: ViewlistUniWidget.routeName,
          path: ViewlistUniWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => ViewlistUniWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: AdminUniversityViewWidget.routeName,
          path: AdminUniversityViewWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => AdminUniversityViewWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: PenddingPageForUniWidget.routeName,
          path: PenddingPageForUniWidget.routePath,
          asyncParams: {
            'uniw': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => PenddingPageForUniWidget(
            uniw: params.getParam(
              'uniw',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: CreateUniversityCopy2Widget.routeName,
          path: CreateUniversityCopy2Widget.routePath,
          builder: (context, params) => CreateUniversityCopy2Widget(),
        ),
        FFRoute(
          name: MentorsListUniverstyWidget.routeName,
          path: MentorsListUniverstyWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => MentorsListUniverstyWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: UniversityMWidget.routeName,
          path: UniversityMWidget.routePath,
          asyncParams: {
            'mento': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => UniversityMWidget(
            mento: params.getParam(
              'mento',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: MentorUniversityViewWidget.routeName,
          path: MentorUniversityViewWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => MentorUniversityViewWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: UniViewMentorDetailsWidget.routeName,
          path: UniViewMentorDetailsWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
            'univ': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => UniViewMentorDetailsWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
            univ: params.getParam(
              'univ',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: UniViewMentorDetailsCopyWidget.routeName,
          path: UniViewMentorDetailsCopyWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => UniViewMentorDetailsCopyWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: EditMajorWidget.routeName,
          path: EditMajorWidget.routePath,
          asyncParams: {
            'majorDoc': getDoc(['Majors'], MajorsRecord.fromSnapshot),
          },
          builder: (context, params) => EditMajorWidget(
            majorDoc: params.getParam(
              'majorDoc',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: EditMajorCopyWidget.routeName,
          path: EditMajorCopyWidget.routePath,
          asyncParams: {
            'majorDoc': getDoc(['Majors'], MajorsRecord.fromSnapshot),
          },
          builder: (context, params) => EditMajorCopyWidget(
            majorDoc: params.getParam(
              'majorDoc',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: EditCollegeWidget.routeName,
          path: EditCollegeWidget.routePath,
          asyncParams: {
            'collegee': getDoc(['colleges'], CollegesRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => EditCollegeWidget(
            collegee: params.getParam(
              'collegee',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: MentorViewMajorWidget.routeName,
          path: MentorViewMajorWidget.routePath,
          asyncParams: {
            'college': getDoc(['colleges'], CollegesRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => MentorViewMajorWidget(
            college: params.getParam(
              'college',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: AdminUniversityViewCopyWidget.routeName,
          path: AdminUniversityViewCopyWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => AdminUniversityViewCopyWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ApproveUniversityWidget.routeName,
          path: ApproveUniversityWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => ApproveUniversityWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: AdminUniversityViewApprovedWidget.routeName,
          path: AdminUniversityViewApprovedWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => AdminUniversityViewApprovedWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: StudentViewMajorWidget.routeName,
          path: StudentViewMajorWidget.routePath,
          asyncParams: {
            'college': getDoc(['colleges'], CollegesRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => StudentViewMajorWidget(
            college: params.getParam(
              'college',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: MentorsListCopyWidget.routeName,
          path: MentorsListCopyWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => MentorsListCopyWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: EditMajorFormWidget.routeName,
          path: EditMajorFormWidget.routePath,
          asyncParams: {
            'college': getDoc(['colleges'], CollegesRecord.fromSnapshot),
            'major': getDoc(['Majors'], MajorsRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => EditMajorFormWidget(
            college: params.getParam(
              'college',
              ParamType.Document,
            ),
            major: params.getParam(
              'major',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: EditCollegeCopyWidget.routeName,
          path: EditCollegeCopyWidget.routePath,
          asyncParams: {
            'collegee': getDoc(['colleges'], CollegesRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => EditCollegeCopyWidget(
            collegee: params.getParam(
              'collegee',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: UniversityProfileCopyCopyCopyWidget.routeName,
          path: UniversityProfileCopyCopyCopyWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => UniversityProfileCopyCopyCopyWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: EditMajor2Widget.routeName,
          path: EditMajor2Widget.routePath,
          asyncParams: {
            'college': getDoc(['colleges'], CollegesRecord.fromSnapshot),
          },
          builder: (context, params) => EditMajor2Widget(
            college: params.getParam(
              'college',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: StudentViewCollageWidget.routeName,
          path: StudentViewCollageWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => StudentViewCollageWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: MentorViewCollageWidget.routeName,
          path: MentorViewCollageWidget.routePath,
          asyncParams: {
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => MentorViewCollageWidget(
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: StudentViewMajorDetailsWidget.routeName,
          path: StudentViewMajorDetailsWidget.routePath,
          asyncParams: {
            'majorDoc': getDoc(['Majors'], MajorsRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
            'collage': getDoc(['colleges'], CollegesRecord.fromSnapshot),
          },
          builder: (context, params) => StudentViewMajorDetailsWidget(
            majorDoc: params.getParam(
              'majorDoc',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
            collage: params.getParam(
              'collage',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: DisappPageForUniWidget.routeName,
          path: DisappPageForUniWidget.routePath,
          asyncParams: {
            'uniw': getDoc(['University'], UniversityRecord.fromSnapshot),
          },
          builder: (context, params) => DisappPageForUniWidget(
            uniw: params.getParam(
              'uniw',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ChatAiScreenWidget.routeName,
          path: ChatAiScreenWidget.routePath,
          builder: (context, params) => ChatAiScreenWidget(),
        ),
        FFRoute(
          name: ChatAiScreen1Widget.routeName,
          path: ChatAiScreen1Widget.routePath,
          builder: (context, params) => ChatAiScreen1Widget(),
        ),
        FFRoute(
          name: ChatMScreenWidget.routeName,
          path: ChatMScreenWidget.routePath,
          asyncParams: {
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => ChatMScreenWidget(
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
            recChat: params.getParam(
              'recChat',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['chats'],
            ),
          ),
        ),
        FFRoute(
          name: AllChatsWidget.routeName,
          path: AllChatsWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
            'mentor': getDoc(['Mentor'], MentorRecord.fromSnapshot),
          },
          builder: (context, params) => AllChatsWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
            mentor: params.getParam(
              'mentor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ChatPageWidget.routeName,
          path: ChatPageWidget.routePath,
          builder: (context, params) => ChatPageWidget(
            reciveChat: params.getParam(
              'reciveChat',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['chatsStudentMentor'],
            ),
          ),
        ),
        FFRoute(
          name: MentorsListChatWidget.routeName,
          path: MentorsListChatWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => MentorsListChatWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: HomePageStudentCopyCopyWidget.routeName,
          path: HomePageStudentCopyCopyWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => HomePageStudentCopyCopyWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: ChatAiScreenCopyWidget.routeName,
          path: ChatAiScreenCopyWidget.routePath,
          builder: (context, params) => ChatAiScreenCopyWidget(),
        ),
        FFRoute(
          name: MentorViewMajorDetailsWidget.routeName,
          path: MentorViewMajorDetailsWidget.routePath,
          asyncParams: {
            'majorDoc': getDoc(['Majors'], MajorsRecord.fromSnapshot),
            'uni': getDoc(['University'], UniversityRecord.fromSnapshot),
            'collage': getDoc(['colleges'], CollegesRecord.fromSnapshot),
          },
          builder: (context, params) => MentorViewMajorDetailsWidget(
            majorDoc: params.getParam(
              'majorDoc',
              ParamType.Document,
            ),
            uni: params.getParam(
              'uni',
              ParamType.Document,
            ),
            collage: params.getParam(
              'collage',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: CalculatorWidget.routeName,
          path: CalculatorWidget.routePath,
          asyncParams: {
            'student': getDoc(['student'], StudentRecord.fromSnapshot),
          },
          builder: (context, params) => CalculatorWidget(
            student: params.getParam(
              'student',
              ParamType.Document,
            ),
          ),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/onboarding01';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Container(
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  child: Image.asset(
                    'assets/images/Animation_-_1725799732461.gif',
                    fit: BoxFit.contain,
                  ),
                )
              : PushNotificationsHandler(child: page);

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
